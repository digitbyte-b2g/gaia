
module.exports = {
  service: require('./src/service'),
  client: require('./src/client'),
  _message: require('./src/message')
};
