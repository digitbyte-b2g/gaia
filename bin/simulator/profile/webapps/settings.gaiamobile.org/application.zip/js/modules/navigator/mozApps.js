define([],function() {
  'use strict';
  return window.navigator.mozApps;
});
