/**
 * The moudle supports displaying bluetooth information on an element.
 *
 * @module panels/root/bluetooth_item
 */
define('panels/root/bluetooth_item',['require','modules/settings_service','modules/bluetooth/bluetooth_context'],function(require) {
  'use strict';

  var SettingsService = require('modules/settings_service');
  var BtContext = require('modules/bluetooth/bluetooth_context');

  var _debug = false;
  var debug = function() {};
  if (_debug) {
    debug = function bti_debug(msg) {
      console.log('--> [BluetoothItem]: ' + msg);
    };
  }

  /**
   * @alias module:panels/root/bluetooth_item
   * @class BluetoothItem
   * @requires module:modules/bluetooth
   * @param {HTMLElement} element
                          The element displaying the bluetooth information
   * @return {BluetoothItem}
   */
  function BluetoothItem(element) {
    this._enabled = false;
    this._element = element;
    this._boundRefreshMenuDescription =
      this._refreshMenuDescription.bind(this, element);
  }

  BluetoothItem.prototype = {
    /**
     * Refresh the text based on the Bluetooth module enabled/disabled,
     * paired devices information.
     *
     * @access private
     * @memberOf BluetoothItem.prototype
     * @param {HTMLElement} element
                            The element displaying the bluetooth information
     */
    _refreshMenuDescription: function bt__refreshMenuDescription(element) {
      if (!navigator.mozL10n) {
        return;
      }

      if (BtContext.enabled) {
        if (BtContext.numberOfPairedDevices === 0) {
          element.setAttribute('data-l10n-id', 'bt-status-nopaired');
        } else {
          navigator.mozL10n.setAttributes(element, 'bt-status-paired',
            {
              name: BtContext.firstPairedDeviceName,
              n: BtContext.numberOfPairedDevices - 1
            });
        }
      } else {
        element.setAttribute('data-l10n-id', 'bt-status-turnoff');
      }
    },

    /**
     * The value indicates whether the module is responding.
     *
     * @access public
     * @memberOf BluetoothItem.prototype
     * @type {Boolean}
     */
    get enabled() {
      return this._enabled;
    },

    set enabled(value) {
      if (this._enabled === value) {
        return;
      }

      this._enabled = value;
      if (this._enabled) {
        BtContext.observe('enabled', this._boundRefreshMenuDescription);
        BtContext.observe('numberOfPairedDevices',
          this._boundRefreshMenuDescription);
        this._boundRefreshMenuDescription();
      } else {
        BtContext.unobserve('enabled', this._boundRefreshMenuDescription);
        BtContext.unobserve('numberOfPairedDevices',
          this._boundRefreshMenuDescription);
      }
    },

    /**
     * Navigate new/old Bluetooth panel via version of mozBluetooth API.
     *
     * @access private
     * @memberOf BluetoothItem.prototype
     * @type {Function}
     */
    _navigatePanelWithVersionCheck:
    function bt__navigatePanelWithVersionCheck() {
      debug('navigate bluetooth panel');
      SettingsService.navigate('bluetooth');
    }
  };

  return function ctor_bluetoothItem(element) {
    return new BluetoothItem(element);
  };
});

/**
 * The moudle supports displaying nfc toggle on an element.
 *
 * @module panels/root/nfc_item
 */
define('panels/root/nfc_item',['require','shared/settings_listener'],function(require) {
  'use strict';

  var SettingsListener = require('shared/settings_listener');

  /**
   * @alias module:panels/root/nfc_item
   * @class NFCItem
   * @param {Object} elements
   * @param {HTMLElement} elements.nfcMenuItem
   * @param {HTMLElement} elements.nfcCheckBox
   * @returns {NFCItem}
   */
  function NFCItem(elements) {
    if (!navigator.mozNfc) {
      return;
    }
    elements.nfcMenuItem.hidden = false;
    this._checkbox = elements.nfcCheckBox;
    this._checkbox.addEventListener('change', () => this._onCheckboxChanged());

    SettingsListener.observe('nfc.status', undefined,
                             (status) => this._onNfcStatusChanged(status));
  }

  NFCItem.prototype = {
    // disabling on change to prevent double clicking and remove toggle
    // flickering before nfcManger will change nfc.status
    _onCheckboxChanged: function ni_onCheckboxChanged() {
      this._checkbox.disabled = true;
    },

    _onNfcStatusChanged: function ni_onNfcStatusChanged(status) {
      if (status === 'enabling' || status === 'disabling') {
        this._checkbox.disabled = true;
      } else if (status === 'enabled' || status === 'disabled') {
        this._checkbox.disabled = false;
      }
    }
  };

  return function ctor_nfcItem(elements) {
    return new NFCItem(elements);
  };
});

/**
 * The moudle supports displaying language information on an element.
 *
 * @module panels/root/language_item
 */
define('panels/root/language_item',['require','shared/language_list'],function(require) {
  'use strict';

  var LanguageList = require('shared/language_list');

  /**
   * @alias module:panels/root/language_item
   * @class LanguageItem
   * @param {HTMLElement} element
                          The element displaying the language information
   * @returns {LanguageItem}
   */
  function LanguageItem(element) {
    this._enabled = false;
    this._boundRefreshText = this._refreshText.bind(this, element);
  }

  LanguageItem.prototype = {
    /**
     * Refresh the text based on the language setting.
     *
     * @access private
     * @memberOf LanguageItem.prototype
     * @param {HTMLElement} element
                            The element displaying the language information
     */
    _refreshText: function l_refeshText(element) {
      // display the current locale in the main panel
      LanguageList.get(function displayLang(languages, currentLanguage) {
        element.textContent = LanguageList.wrapBidi(
          currentLanguage, languages[currentLanguage]);
      });
    },

    /**
     * The value indicates whether the module is responding.
     *
     * @access public
     * @memberOf LanguageItem.prototype
     * @type {Boolean}
     */
    get enabled() {
      return this._enabled;
    },

    set enabled(value) {
      if (this._enabled === value || !navigator.mozL10n) {
        return;
      }
      
      this._enabled = value;
      if (this._enabled) {
        window.addEventListener('localized', this._boundRefreshText);
        this._boundRefreshText();
      } else {
        window.removeEventListener('localized', this._boundRefreshText);
      }
    }
  };

  return function ctor_languageItem(element) {
    return new LanguageItem(element);
  };
});

/**
 * The moudle supports displaying battery information on an element.
 *
 * @module panels/root/battery_item
 */
define('panels/root/battery_item',['require','modules/battery'],function(require) {
  'use strict';

  var Battery = require('modules/battery');

  /**
   * @alias module:panels/root/battery_item
   * @class BatteryItem
   * @requires module:modules/battery
   * @param {HTMLElement} element
                          The element displaying the battery information
   * @returns {BatteryItem}
   */
  function BatteryItem(element) {
    this._enabled = false;
    this._element = element;
    this._boundRefreshText = this._refreshText.bind(this, element);
  }

  BatteryItem.prototype = {
    /**
     * Refresh the text based on the Battery module.
     *
     * @access private
     * @memberOf BatteryItem.prototype
     * @param {HTMLElement} element
                            The element displaying the battery information
     */
    _refreshText: function b_refreshText(element) {
      if (!navigator.mozL10n) {
        return;
      }

      navigator.mozL10n.setAttributes(element,
        'batteryLevel-percent-' + Battery.state, { level: Battery.level });
      if (element.hidden) {
        element.hidden = false;
      }
    },

    /**
     * The value indicates whether the module is responding.
     *
     * @access public
     * @memberOf BatteryItem.prototype
     * @type {Boolean}
     */
    get enabled() {
      return this._enabled;
    },

    set enabled(value) {
      if (this._enabled === value) {
        return;
      }
      
      this._enabled = value;
      if (this._enabled) {
        Battery.observe('level', this._boundRefreshText);
        Battery.observe('state', this._boundRefreshText);
        this._boundRefreshText();
      } else {
        Battery.unobserve('level', this._boundRefreshText);
        Battery.unobserve('state', this._boundRefreshText);
      }
    }
  };

  return function ctor_batteryItem(element) {
    return new BatteryItem(element);
  };
});

/* global SettingsListener */

/**
 * This module display Find My Device's enabled/disabled state on an
 * element.
 *
 * @module panels/root/findmydevice_item
 */
define('panels/root/findmydevice_item',['require'],function(require) {
  'use strict';

  /**
   * @alias module:panels/root/findmydevice_item
   * @class FindMyDeviceItem
   * @param {HTMLElement} element
                          The element displaying Find My Device's enabled state
   * @returns {FindMyDeviceItem}
   */
  function FindMyDeviceItem(element) {
    this._itemEnabled = false;
    this._FMDEnabled = false;
    this._boundRefreshText = this._refreshText.bind(this, element);
    this._boundFMDEnabledChanged = this._onFMDEnabledChanged.bind(this);
  }

  FindMyDeviceItem.prototype = {
    /**
     * Refresh the text based on Find My Device's enabled state
     *
     * @access private
     * @memberOf FindMyDeviceItem.prototype
     * @param {HTMLElement} element
                            The element showing Find My Device's enabled state
     */
    _refreshText: function fmd_refresh_text(element) {
      if (!navigator.mozL10n) {
        return;
      }

      element.setAttribute('data-l10n-id',
                           this._FMDEnabled ? 'enabled' : 'disabled');
      element.hidden = false;
    },

    /**
     * Listener for changes in Find My Device's enabled state. Updates the
     * text if this item is enabled.
     *
     * @access private
     * @memberOf FindMyDeviceItem.prototype
     * @param {Boolean} value
                        The current enabled state for Find My Device
     */
    _onFMDEnabledChanged: function fmd_enabled_changed(value) {
      this._FMDEnabled = value;
      if (this._itemEnabled) {
        this._boundRefreshText();
      }
    },

    /**
     * The value indicates whether the module is responding.
     *
     * @access public
     * @memberOf FindMyDeviceItem.prototype
     * @type {Boolean}
     */
    get enabled() {
      return this._itemEnabled;
    },

    set enabled(value) {
      if (this._itemEnabled === value) {
        return;
      }

      this._itemEnabled = value;
      if (this._itemEnabled) {
        SettingsListener.observe('findmydevice.enabled', false,
          this._boundFMDEnabledChanged);
      } else {
        SettingsListener.unobserve('findmydevice.enabled',
          this._boundFMDEnabledChanged);
      }
    }
  };

  return function ctor_findMyDeviceItem(element) {
    return new FindMyDeviceItem(element);
  };
});

/* global DeviceStorageHelper */
/**
 * Links the root panel list item with USB Mass Storage(UMS).
 * Will disable Media Storage panel when UMS enabled.
 */
define('panels/root/storage_usb_item',['require','shared/settings_listener','modules/media_storage'],function(require) {
  'use strict';

  var SettingsListener = require('shared/settings_listener');
  var MediaStorage = require('modules/media_storage');

  var _debug = false;
  var debug = function() {};
  if (_debug) {
    debug = function storage_debug(msg) {
      console.log('--> [USBStorageItem]: ' + msg);
    };
  }

  /**
   * @alias module:panels/root/storage_usb_item
   * @class USBStorageItem
   * @param {Object} elements
                     elements displaying the usb and media storage information
   * @returns {USBStorageItem}
   */
  function USBStorageItem(elements) {
    this._enabled = false;
    this._elements = elements;
    this._keyUmsEnabled = 'ums.enabled';

    this._boundUmsEnabledHandler = this._umsEnabledHandler.bind(this);
    this._boundUpdateVolumeState = this._updateVolumeState.bind(this);
  }

  USBStorageItem.prototype = {
    /**
     * The value indicates whether the module is responding. If it is false, the
     * UI stops reflecting the updates from the root panel context.
     *
     * @access public
     * @memberOf USBStorageItem.prototype
     * @type {Boolean}
     */
    get enabled() {
      return this._enabled;
    },

    set enabled(value) {
      if (this._enabled === value) {
        return;
      } else {
        this._enabled = value;
      }
      if (value) { //observe
        SettingsListener.observe(this._keyUmsEnabled, false,
          this._boundUmsEnabledHandler);
        MediaStorage.observe('volumeState', this._boundUpdateVolumeState);
        MediaStorage.observe('freeSize', this._boundUpdateVolumeState);

        window.addEventListener('localized', this);
      } else { //unobserve
        SettingsListener.unobserve(this._keyUmsEnabled,
          this._boundUmsEnabledHandler);
        MediaStorage.unobserve('volumeState', this._boundUpdateVolumeState);
        MediaStorage.unobserve('freeSize', this._boundUpdateVolumeState);

        window.removeEventListener('localized', this);
      }
    },

    _umsEnabledHandler: function storage_umsEnabledHandler(enabled) {
      debug('_umsEnabledHandler');
      this._enabled = enabled;
      this._updateUmsDesc();
    },

    handleEvent: function storage_handleEvent(evt) {
      switch (evt.type) {
        case 'localized':
          this._updateVolumeState();
          break;
      }
    },

    // ums description
    _updateUmsDesc: function storage_updateUmsDesc() {
      var key;
      debug('enabled:' + this._enabled + '/' +
            'volumeState:' + MediaStorage.volumeState);
      if (this._enabled) {
        //TODO list all enabled volume name
        key = 'enabled';
      } else if (MediaStorage.volumeState === 'shared') {
        key = 'umsUnplugToDisable';
      } else {
        key = 'disabled';
      }
      this._elements.usbEnabledInfoBlock.setAttribute('data-l10n-id', key);
    },

    _updateVolumeState: function storage_updateVolumeState() {
      debug('_updateVolumeState');
      this._updateUmsDesc();
      switch (MediaStorage.volumeState) {
        case 'available':
          DeviceStorageHelper.showFormatedSize(this._elements.mediaStorageDesc,
            'availableSize', MediaStorage.freeSize);
          this._lockMediaStorageMenu(false);
          break;

        case 'shared':
          this._elements.mediaStorageDesc.removeAttribute('data-l10n-id');
          this._elements.mediaStorageDesc.textContent = '';
          this._lockMediaStorageMenu(false);
          break;

        case 'unavailable':
          this._elements.mediaStorageDesc.setAttribute('data-l10n-id',
                                                       'no-storage');
          this._lockMediaStorageMenu(true);
          break;
      }
    },

    _lockMediaStorageMenu: function storage_setMediaMenuState(lock) {
      if (lock) {
        this._elements.mediaStorageSection.setAttribute('aria-disabled', true);
      } else {
        this._elements.mediaStorageSection.removeAttribute('aria-disabled');
      }
    }
  };

  return function ctor_usb_storage_item(elements) {
    return new USBStorageItem(elements);
  };
});

/* global DeviceStorageHelper */
/**
 * Links the root panel list item with AppStorage.
 */
define('panels/root/storage_app_item',['require','modules/app_storage'],function(require) {
  'use strict';

  var AppStorage = require('modules/app_storage');

  /**
   * @alias module:panels/root/storage_app_item
   * @class AppStorageItem
   * @requires module:modules/app_storage
   * @param {HTMLElement} element
                          The element displaying the app storage information
   * @returns {AppStorageItem}
   */
  function AppStorageItem(element) {
    this._enabled = false;
    this._element = element;
    this._boundUpdateAppFreeSpace = this._updateAppFreeSpace.bind(this);
  }

  AppStorageItem.prototype = {
    /**
     * The value indicates whether the module is responding. If it is false, the
     * UI stops reflecting the updates from the root panel context.
     *
     * @access public
     * @memberOf AppStorageItem.prototype
     * @type {Boolean}
     */
    get enabled() {
      return this._enabled;
    },

    set enabled(value) {
      if (this._enabled === value) {
        return;
      } else {
        this._enabled = value;
      }
      if (value) { //observe
        AppStorage.observe('freeSize', this._boundUpdateAppFreeSpace);
        this._updateAppFreeSpace();
        window.addEventListener('localized', this);
      } else { //unobserve
        AppStorage.unobserve('freeSize', this._boundUpdateAppFreeSpace);
        window.removeEventListener('localized', this);
      }
    },

    // Application Storage
    _updateAppFreeSpace: function storage_updateAppFreeSpace() {
      DeviceStorageHelper.showFormatedSize(this._element,
        'availableSize', AppStorage.freeSize);
    },

    handleEvent: function storage_handleEvent(evt) {
      switch (evt.type) {
        case 'localized':
          this._updateAppFreeSpace();
          break;
      }
    }
  };

  return function ctor_app_storage_item(element) {
    return new AppStorageItem(element);
  };
});

define('panels/root/wifi_item',['require','modules/wifi_context'],function(require) {
  'use strict';

  var WifiContext = require('modules/wifi_context');

  function WifiItem(element) {
    this._enabled = false;
    this._boundUpdateWifiDesc = this._updateWifiDesc.bind(this, element);
  }

  WifiItem.prototype = {
    set enabled(value) {
      if (value === this._enabled || !navigator.mozWifiManager) {
        return;
      }

      this._enabled = value;
      if (this._enabled) {
        this._boundUpdateWifiDesc();
        WifiContext.addEventListener('wifiStatusTextChange',
          this._boundUpdateWifiDesc);
      } else {
        WifiContext.removeEventListener('wifiStatusTextChange',
          this._boundUpdateWifiDesc);
      }
    },

    get enabled() {
      return this._enabled;
    },

    _updateWifiDesc: function root_updateWifiDesc(element) {
      element.setAttribute('data-l10n-id', WifiContext.wifiStatusText.id);
      if (WifiContext.wifiStatusText.args) {
        element.setAttribute('data-l10n-args',
          JSON.stringify(WifiContext.wifiStatusText.args));
      } else {
        element.removeAttribute('data-l10n-args');
      }
      // Bug 1217717 enable the Airplane mode interaction
      // once the wifi panel is ready
      window.dispatchEvent(new CustomEvent('wificontext-ready'));
    }
  };

  return function ctor_wifiItem(element) {
    return new WifiItem(element);
  };
});

define('panels/root/screen_lock_item',['require','shared/settings_listener'],function(require) {
  'use strict';

  var SettingsListener = require('shared/settings_listener');

  function ScreenLockItem(element) {
    this._itemEnabled = false;
    this._lockscreenEnable = false;
    this._lockscreenEnableEvent = 'lockscreen.enabled';
    this._lockscreenPasscodeEnableEvent = 'lockscreen.passcode-lock.enabled';
    this._element = element;
    this._boundUpdateEnable = this._updateEnable.bind(this);
    this._boundUpdatePasscodeEnable = this._updatePasscodeEnable.bind(this);
  }

  ScreenLockItem.prototype = {
    set enabled(value) {
      if (value === this._itemEnabled) {
        return;
      } else {
        this._itemEnabled = value;
        if (this._itemEnabled) {
          SettingsListener.observe(this._lockscreenEnableEvent, false,
            this._boundUpdateEnable);
          SettingsListener.observe(this._lockscreenPasscodeEnableEvent, false,
            this._boundUpdatePasscodeEnable);
        } else {
          SettingsListener.unobserve(this._lockscreenEnableEvent,
            this._boundUpdateEnable);
          SettingsListener.unobserve(this._lockscreenPasscodeEnableEvent,
            this._boundUpdatePasscodeEnable);
        }
      }
    },

    get enabled() {
      return this._itemEnabled;
    },

    _updateEnable: function sl_updateEnable(enabled) {
      this._lockscreenEnable = enabled;
      var l10nId = enabled ? 'screenLock-enabled-with-no-passcode' : 'disabled';
      this._element.setAttribute('data-l10n-id', l10nId);
    },

    _updatePasscodeEnable: function sl_updatePasscodeEnable(enabled) {
      var l10nId = 'disabled';
      if (this._lockscreenEnable) {
        l10nId = enabled ?
          'screenLock-enabled-with-passcode' :
          'screenLock-enabled-with-no-passcode';
      }
      this._element.setAttribute('data-l10n-id', l10nId);
    }
  };

  return function ctor_screen_lock_item(element) {
    return new ScreenLockItem(element);
  };
});

/**
 * SimSecurityItem is manily used in Single Sim device because this would
 * be integrated into Sim Manager > Sim Security in DSDS devices.
 *
 * @module SimSecurityItem
 */
define('panels/root/sim_security_item',['require','shared/simslot_manager','shared/airplane_mode_helper','modules/sim_security'],function(require) {
  'use strict';

  var SIMSlotManager = require('shared/simslot_manager');
  var AirplaneModeHelper = require('shared/airplane_mode_helper');
  var SimSecurity = require('modules/sim_security');

  function SimSecurityItem(element) {
    this._element = element;
    this._itemEnabled = false;
    this._cardIndex = 0;
    this._activeSlot = this._getActiveSlot();
    this._boundUpdateUI = this._updateUI.bind(this);

    // Note
    // Because we can't rely on Gecko's oncardstatechange, we have to
    // update UI based on our customized events.
    SimSecurity.addEventListener('pin-enabled', () => {
      this._boundUpdateUI();
    });

    SimSecurity.addEventListener('pin-disabled', () => {
      this._boundUpdateUI();
    });
  }

  SimSecurityItem.prototype = {
    /**
     * Set the current status of SimSecurityItem
     *
     * @access public
     * @param {Boolean} enabled
     * @memberOf SimSecurityItem
     */
    set enabled(enabled) {
      // 1. SimSecurityItem only shows up on Single SIM devices
      // 2. If there is no activeSlot, it means we don't have to do anything
      // 3. If internal variable is enabled and we still want to enable,
      // we don't have to do anything and vice versa.
      if (SIMSlotManager.isMultiSIM() ||
        !this._activeSlot || enabled === this._itemEnabled) {
          return;
      }

      this._itemEnabled = enabled;
      if (this._itemEnabled) {
        this._boundUpdateUI();
        AirplaneModeHelper.addEventListener('statechange',
          this._boundUpdateUI);
      } else {
        AirplaneModeHelper.removeEventListener('statechange',
          this._boundUpdateUI);
      }
    },

    /**
     * Get the current status of SimSecurityItem
     *
     * @access public
     * @memberOf SimSecurityItem
     */
    get enabled() {
      return this._itemEnabled;
    },

    /**
     * This method is used to update UI based on statuses of SIM / APM
     *
     * @access private
     * @memberOf SimSecurityItem
     */
    _updateUI: function() {
      var promise = new Promise((resolve) => {
        AirplaneModeHelper.ready(() => {
          // if disabled
          this._element.style.fontStyle = 'italic';

          // if APM is enabled
          var airplaneModeStatus = AirplaneModeHelper.getStatus();
          if (airplaneModeStatus === 'enabled') {
            this._element.setAttribute('data-l10n-id', 'simCardNotReady');
            return resolve();
          }

          var cardState = this._activeSlot.simCard.cardState;
          switch(cardState) {
            case null:
              this._element.setAttribute('data-l10n-id', 'noSimCard');
              return resolve();
            case 'unknown':
              this._element.setAttribute('data-l10n-id', 'unknownSimCardState');
              return resolve();
          }

          // enabled instead
          this._element.style.fontStyle = 'normal';

          SimSecurity.getCardLock(this._cardIndex, 'pin').then((result) => {
            var enabled = result.enabled;
            this._element.setAttribute('data-l10n-id',
              enabled ? 'enabled' : 'disabled');
            return resolve();
          });
        });
      });

      return promise;
    },

    /**
     * We use this to get active Sim slot.
     *
     * @access private
     * @memberOf SimSecurityItem
     */
    _getActiveSlot: function() {
      var slot = SIMSlotManager.get(this._cardIndex);
      if (slot && !slot.isAbsent()) {
        return slot;
      }
    }
  };

  return function ctor_sim_security_item(element) {
    return new SimSecurityItem(element);
  };
});

/**
 * This module contains modules for the low priority items in the root panel.
 * The module should only be loaded after the menu items are ready for user
 * interaction.
 *
 * @module panels/root/low_priority_items
 */
define('panels/root/low_priority_items',['require','panels/root/bluetooth_item','panels/root/nfc_item','panels/root/language_item','panels/root/battery_item','panels/root/findmydevice_item','panels/root/storage_usb_item','panels/root/storage_app_item','panels/root/wifi_item','panels/root/screen_lock_item','panels/root/sim_security_item'],function(require) {
  'use strict';

  var items = {
    BluetoothItem: require('panels/root/bluetooth_item'),
    NFCItem: require('panels/root/nfc_item'),
    LanguageItem: require('panels/root/language_item'),
    BatteryItem: require('panels/root/battery_item'),
    FindMyDeviceItem: require('panels/root/findmydevice_item'),
    StorageUSBItem: require('panels/root/storage_usb_item'),
    StorageAppItem: require('panels/root/storage_app_item'),
    WifiItem: require('panels/root/wifi_item'),
    ScreenLockItem: require('panels/root/screen_lock_item'),
    SimSecurityItem: require('panels/root/sim_security_item')
  };

  return {
    get BluetoothItem()    { return items.BluetoothItem; },
    get NFCItem()          { return items.NFCItem; },
    get LanguageItem()     { return items.LanguageItem; },
    get BatteryItem()      { return items.BatteryItem; },
    get FindMyDeviceItem() { return items.FindMyDeviceItem; },
    get StorageUSBItem()   { return items.StorageUSBItem; },
    get StorageAppItem()   { return items.StorageAppItem; },
    get WifiItem()         { return items.WifiItem; },
    get ScreenLockItem()   { return items.ScreenLockItem; },
    get SimSecurityItem()  { return items.SimSecurityItem; }
  };
});

