// This file is generated. Do not edit.
// @generated
import Services from '../shared/services.js';
import SessionObject from '../shared/sessionobject.js';
import {Encoder, Decoder, wrapBlob} from '../shared/bincode.js';
class TcpSocketSession extends SessionObject {
constructor(object_id, service_id, session) {
super(object_id , session, service_id, TcpSocketMessages);
session.track_events(service_id, object_id, this);
}
close(){
return this.call_method("Close", {});
}
resume(){
return this.call_method("Resume", {});
}
send(data){
return this.call_method("Send", {data: data});
}
suspend(){
return this.call_method("Suspend", {});
}
on_event(event) {
// console.log(`TcpSocketSession message: ${event}`);
let decoder = new Decoder(event);
let variant = decoder.enum_tag();
// Event #8: CLOSE
if (variant == 8) {
let result = null;
// decoding <no_name>
result = decoder.void();
this.dispatchEvent(0, result);
}
// Event #9: DATA
else if (variant == 9) {
let result = null;
// decoding <no_name>
result = decoder.u8_array();
this.dispatchEvent(1, result);
}
// Event #10: DRAIN
else if (variant == 10) {
let result = null;
// decoding <no_name>
result = decoder.bool();
this.dispatchEvent(2, result);
}
// Event #11: ERROR
else if (variant == 11) {
let result = null;
// decoding <no_name>
result = decoder.string();
this.dispatchEvent(3, result);
}
else {
 console.error(`Unable to process variant #${variant}`); }
}
}

TcpSocketSession.prototype.CLOSE_EVENT = 0;
TcpSocketSession.prototype.DATA_EVENT = 1;
TcpSocketSession.prototype.DRAIN_EVENT = 2;
TcpSocketSession.prototype.ERROR_EVENT = 3;
const TcpSocketMessages = {
CloseRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(0);
return result.value();
}
},
CloseResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 0) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 1) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`CloseResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
ResumeRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(1);
return result.value();
}
},
ResumeResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 2) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 3) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`ResumeResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SendRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(2);
result = result.u8_array(data.data);
return result.value();
}
},
SendResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 4) {
// Success
let result = null;
// decoding <no_name>
result = decoder.bool();
return { success: result }
}
else if (variant == 5) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`SendResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SuspendRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(3);
return result.value();
}
},
SuspendResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 6) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 7) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`SuspendResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
}

class TcpSocketFactorySession extends SessionObject {
constructor(object_id, service_id, session) {
super(object_id , session, service_id, TcpSocketFactoryMessages);
}
open(addr){
return this.call_method("Open", {addr: addr});
}
}

const TcpSocketFactoryMessages = {
OpenRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(4);
// SocketAddress
function EncodeSocketAddress(SocketAddressItem, result) {
result = result.string(SocketAddressItem.host);
result = result.i64(SocketAddressItem.port);
return result;
}
result = EncodeSocketAddress(data.addr, result);
return result.value();
}
},
OpenResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 12) {
// Success
let result = null;
// decoding <no_name>
result = new TcpSocketSession(decoder.u32(), service_id, session);return { success: result }
}
else if (variant == 13) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`OpenResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
}

export const TcpSocketManager = {
            get: (session) => {
                return Services.get("TcpSocketManager", "80b7d391444db6fd2eca3b489c6c4aac8144ad3de7852f5b476abb17bf", session).then((service_id) => {
                    session.registerService(service_id, "TcpSocketManager");
                    // object_id is always 0 for the service itself.
                    return new TcpSocketFactorySession(0, service_id, session);
                });
            },
        };
