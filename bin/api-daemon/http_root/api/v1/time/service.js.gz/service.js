// This file is generated. Do not edit.
// @generated
import Services from '../shared/services.js';
import SessionObject from '../shared/sessionobject.js';
import {Encoder, Decoder, wrapBlob} from '../shared/bincode.js';
export const CallbackReason = {
NONE:0,
TIME_CHANGED:1,
TIMEZONE_CHANGED:2,
}

class TimeSession extends SessionObject {
constructor(object_id, service_id, session) {
super(object_id , session, service_id, TimeMessages);
session.track_events(service_id, object_id, this);
}
addObserver(reason,observer){
let observer__ = observer;
if (typeof observer === 'function') {
observer = TimeObserverBase.fromFunction(this.service_id, this.session, observer__);
}
return this.call_method("AddObserver", {reason: reason,observer: observer});
}
get(){
return this.call_method("Get", {});
}
getElapsedRealTime(){
return this.call_method("GetElapsedRealTime", {});
}
removeObserver(reason,observer){
let observer__ = observer;
if (typeof observer === 'function') {
observer = TimeObserverBase.fromFunction(this.service_id, this.session, observer__);
}
return this.call_method("RemoveObserver", {reason: reason,observer: observer});
}
set(time){
return this.call_method("Set", {time: time});
}
setTimezone(timezone){
return this.call_method("SetTimezone", {timezone: timezone});
}
on_event(event) {
// console.log(`TimeSession message: ${event}`);
let decoder = new Decoder(event);
let variant = decoder.enum_tag();
// Event #12: TIME_CHANGED
if (variant == 12) {
let result = null;
// decoding <no_name>
result = decoder.void();
this.dispatchEvent(0, result);
}
// Event #13: TIMEZONE_CHANGED
else if (variant == 13) {
let result = null;
// decoding <no_name>
result = decoder.void();
this.dispatchEvent(1, result);
}
else {
 console.error(`Unable to process variant #${variant}`); }
}
}

TimeSession.prototype.TIME_CHANGED_EVENT = 0;
TimeSession.prototype.TIMEZONE_CHANGED_EVENT = 1;
const TimeMessages = {
AddObserverRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(0);
result = result.enum_tag(data.reason);
result = result.u32(data.observer.id);
return result.value();
}
},
AddObserverResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 0) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 1) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`AddObserverResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(1);
return result.value();
}
},
GetResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 2) {
// Success
let result = null;
// decoding <no_name>
result = decoder.date();
return { success: result }
}
else if (variant == 3) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetElapsedRealTimeRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(2);
return result.value();
}
},
GetElapsedRealTimeResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 4) {
// Success
let result = null;
// decoding <no_name>
result = decoder.i64();
return { success: result }
}
else if (variant == 5) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetElapsedRealTimeResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
RemoveObserverRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(3);
result = result.enum_tag(data.reason);
result = result.u32(data.observer.id);
return result.value();
}
},
RemoveObserverResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 6) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 7) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`RemoveObserverResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SetRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(4);
result = result.date(data.time);
return result.value();
}
},
SetResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 8) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 9) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`SetResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SetTimezoneRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(5);
result = result.string(data.timezone);
return result.value();
}
},
SetTimezoneResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 10) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 11) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`SetTimezoneResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
}

export class TimeObserverBase extends SessionObject {
constructor(service_id, session) {
super(session.next_id , session, service_id, null);
session.track(this);
}
static fromFunction(service_id, session, fn) {
let obj = new TimeObserverBase(service_id, session);
obj.callback = fn.bind(obj);
return obj;
}
on_message(message) {
            // console.log(`Message for TimeObserver ${this.display()}: %o`, message);
let decoder = new Decoder(message.content);
        let variant = decoder.enum_tag();
        // console.log(`Starting at index 14`);
        // console.log(`we got variant ${variant}`);
        // Dispatch based on message.content which is the real payload.
        
switch (variant) {
case 14: {
// console.log(`Extracting parameters for callback(...)`);
if (this.callback && this.callback instanceof Function) {
let result = {};
// decoding info
function DecodeTimeInfo(decoder) {
let TimeInfoItem = {};
// decoding reason
TimeInfoItem.reason = decoder.enum_tag();
// decoding timezone
TimeInfoItem.timezone = decoder.string();
// decoding delta
TimeInfoItem.delta = decoder.i64();
return TimeInfoItem;
}
result = DecodeTimeInfo(decoder);
let output = this.callback(
result
);
output.then(
success => { // console.log(`TimeObserver.callback success: ${success}`);
let encoder = new Encoder();
let result = encoder.enum_tag(6);
result = result.void(success);
message.content = result.value();
this.send_callback_message(message);
},
error => { // console.error(`TimeObserver.callback error: ${error}`);
let encoder = new Encoder();
let result = encoder.enum_tag(7);
result = result.void(error);
message.content = result.value();
this.send_callback_message(message);
}
);
}
break; }
default: console.error(`Unexpected variant: ${variant}`);
}
}
}

export const TimeService = {
            get: (session) => {
                return Services.get("TimeService", "d76f2b662bafaf981ee817c61e66698be414446732db362e245ace81c399928", session).then((service_id) => {
                    session.registerService(service_id, "TimeService");
                    // object_id is always 0 for the service itself.
                    return new TimeSession(0, service_id, session);
                });
            },
        };
