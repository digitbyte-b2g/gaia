// This file is generated. Do not edit.
// @generated
import Services from '../shared/services.js';
import SessionObject from '../shared/sessionobject.js';
import {Encoder, Decoder, wrapBlob} from '../shared/bincode.js';
export const FactoryResetReason = {
NORMAL:0,
WIPE:1,
ROOT:2,
}

export const ScreenState = {
ON:0,
OFF:1,
}

class PowermanagerSession extends SessionObject {
constructor(object_id, service_id, session) {
super(object_id , session, service_id, PowermanagerMessages);
}
controlScreen(info){
return this.call_method("ControlScreen", {info: info});
}
powerOff(){
return this.call_method("PowerOff", {});
}
reboot(){
return this.call_method("Reboot", {});
}
get cpuSleepAllowed() {
return this.call_method("GetCpuSleepAllowed");
}
set cpuSleepAllowed(value) {
return this.call_method_oneway("SetCpuSleepAllowed", { value });
}
get extScreenBrightness() {
return this.call_method("GetExtScreenBrightness");
}
set extScreenBrightness(value) {
return this.call_method_oneway("SetExtScreenBrightness", { value });
}
get extScreenEnabled() {
return this.call_method("GetExtScreenEnabled");
}
set extScreenEnabled(value) {
return this.call_method_oneway("SetExtScreenEnabled", { value });
}
get factoryReset() {
return this.call_method("GetFactoryReset");
}
set factoryReset(value) {
return this.call_method_oneway("SetFactoryReset", { value });
}
get keyLightBrightness() {
return this.call_method("GetKeyLightBrightness");
}
set keyLightBrightness(value) {
return this.call_method_oneway("SetKeyLightBrightness", { value });
}
get keyLightEnabled() {
return this.call_method("GetKeyLightEnabled");
}
set keyLightEnabled(value) {
return this.call_method_oneway("SetKeyLightEnabled", { value });
}
get screenBrightness() {
return this.call_method("GetScreenBrightness");
}
set screenBrightness(value) {
return this.call_method_oneway("SetScreenBrightness", { value });
}
get screenEnabled() {
return this.call_method("GetScreenEnabled");
}
set screenEnabled(value) {
return this.call_method_oneway("SetScreenEnabled", { value });
}
}

const PowermanagerMessages = {
ControlScreenRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(0);
// ScreenControlInfo
function EncodeScreenControlInfo(ScreenControlInfoItem, result) {
result = result.bool(ScreenControlInfoItem.state !== undefined);
if (ScreenControlInfoItem.state !== undefined) {
result = result.enum_tag(ScreenControlInfoItem.state);
}
result = result.bool(ScreenControlInfoItem.brightness !== undefined);
if (ScreenControlInfoItem.brightness !== undefined) {
result = result.i64(ScreenControlInfoItem.brightness);
}
result = result.bool(ScreenControlInfoItem.isExternal);
return result;
}
result = EncodeScreenControlInfo(data.info, result);
return result.value();
}
},
ControlScreenResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 0) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 1) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`ControlScreenResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
PowerOffRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(1);
return result.value();
}
},
PowerOffResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 2) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 3) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`PowerOffResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
RebootRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(2);
return result.value();
}
},
RebootResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 4) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 5) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`RebootResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetCpuSleepAllowedRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(3);
return result.value();
}
},
GetCpuSleepAllowedResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 6) {
// Success
let result = null;
// decoding <no_name>
result = decoder.bool();
return { success: result }
}
else {
console.error(`GetCpuSleepAllowedResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SetCpuSleepAllowedRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(4);
result = result.bool(data.value);
return result.value();
}
},
GetExtScreenBrightnessRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(5);
return result.value();
}
},
GetExtScreenBrightnessResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 7) {
// Success
let result = null;
// decoding <no_name>
result = decoder.i64();
return { success: result }
}
else {
console.error(`GetExtScreenBrightnessResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SetExtScreenBrightnessRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(6);
result = result.i64(data.value);
return result.value();
}
},
GetExtScreenEnabledRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(7);
return result.value();
}
},
GetExtScreenEnabledResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 8) {
// Success
let result = null;
// decoding <no_name>
result = decoder.bool();
return { success: result }
}
else {
console.error(`GetExtScreenEnabledResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SetExtScreenEnabledRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(8);
result = result.bool(data.value);
return result.value();
}
},
GetFactoryResetRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(9);
return result.value();
}
},
GetFactoryResetResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 9) {
// Success
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { success: result }
}
else {
console.error(`GetFactoryResetResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SetFactoryResetRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(10);
result = result.enum_tag(data.value);
return result.value();
}
},
GetKeyLightBrightnessRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(11);
return result.value();
}
},
GetKeyLightBrightnessResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 10) {
// Success
let result = null;
// decoding <no_name>
result = decoder.i64();
return { success: result }
}
else {
console.error(`GetKeyLightBrightnessResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SetKeyLightBrightnessRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(12);
result = result.i64(data.value);
return result.value();
}
},
GetKeyLightEnabledRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(13);
return result.value();
}
},
GetKeyLightEnabledResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 11) {
// Success
let result = null;
// decoding <no_name>
result = decoder.bool();
return { success: result }
}
else {
console.error(`GetKeyLightEnabledResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SetKeyLightEnabledRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(14);
result = result.bool(data.value);
return result.value();
}
},
GetScreenBrightnessRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(15);
return result.value();
}
},
GetScreenBrightnessResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 12) {
// Success
let result = null;
// decoding <no_name>
result = decoder.i64();
return { success: result }
}
else {
console.error(`GetScreenBrightnessResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SetScreenBrightnessRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(16);
result = result.i64(data.value);
return result.value();
}
},
GetScreenEnabledRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(17);
return result.value();
}
},
GetScreenEnabledResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 13) {
// Success
let result = null;
// decoding <no_name>
result = decoder.bool();
return { success: result }
}
else {
console.error(`GetScreenEnabledResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SetScreenEnabledRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(18);
result = result.bool(data.value);
return result.value();
}
},
}

export const PowermanagerService = {
            get: (session) => {
                return Services.get("PowermanagerService", "ed49919be5f74c4216eeb714d347f3d32cf3558da5e131819f7fdbd9b2b26", session).then((service_id) => {
                    session.registerService(service_id, "PowermanagerService");
                    // object_id is always 0 for the service itself.
                    return new PowermanagerSession(0, service_id, session);
                });
            },
        };
