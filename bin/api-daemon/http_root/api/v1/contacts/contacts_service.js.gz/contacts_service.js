// This file is generated. Do not edit.
              // @generated
              import Services from '../../../../common/client/src/services';
              import SessionObject from '../../../../common/client/src/sessionobject';
              import {Encoder, Decoder} from '../../../../common/client/src/bincode.js';
export const ChangeReason = {
CREATE:0,
UPDATE:1,
REMOVE:2,
}

export const FilterByOption = {
NAME:0,
GIVEN_NAME:1,
FAMILY_NAME:2,
TEL:3,
EMAIL:4,
CATEGORY:5,
}

export const FilterOption = {
EQUALS:0,
CONTAINS:1,
MATCH:2,
STARTS_WITH:3,
FUZZY_MATCH:4,
}

export const Order = {
ASCENDING:0,
DESCENDING:1,
}

export const SortOption = {
GIVEN_NAME:0,
FAMILY_NAME:1,
NAME:2,
}

class ContactCursorSession extends SessionObject {
constructor(object_id, service_id, session) {
super(object_id , session, service_id, ContactCursorMessages);
}
next(){
return this.call_method("Next", {});
}
}

const ContactCursorMessages = {
NextRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(0);
return result.value();
}
},
NextResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 0) {
// Success
let result = null;
// decoding <no_name>
{
let count = decoder.u64();
result = [];
for (let i = 0; i < count; i++) {
function DecodeContactInfo(decoder) {
let ContactInfoItem = {};
// decoding id
if (decoder.bool()) {
ContactInfoItem.id = decoder.string();
}
// decoding published
if (decoder.bool()) {
ContactInfoItem.published = decoder.date();
}
// decoding updated
if (decoder.bool()) {
ContactInfoItem.updated = decoder.date();
}
// decoding bday
if (decoder.bool()) {
ContactInfoItem.bday = decoder.date();
}
// decoding anniversary
if (decoder.bool()) {
ContactInfoItem.anniversary = decoder.date();
}
// decoding sex
if (decoder.bool()) {
ContactInfoItem.sex = decoder.string();
}
// decoding genderIdentity
if (decoder.bool()) {
ContactInfoItem.genderIdentity = decoder.string();
}
// decoding ringtone
if (decoder.bool()) {
ContactInfoItem.ringtone = decoder.string();
}
// decoding photoType
if (decoder.bool()) {
ContactInfoItem.photoType = decoder.string();
}
// decoding photoBlob
if (decoder.bool()) {
ContactInfoItem.photoBlob = decoder.u8_array();
}
// decoding addresses
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.addresses = [];
for (let i = 0; i < count; i++) {
function DecodeAddress(decoder) {
let AddressItem = {};
// decoding atype
if (decoder.bool()) {
AddressItem.atype = decoder.string();
}
// decoding streetAddress
if (decoder.bool()) {
AddressItem.streetAddress = decoder.string();
}
// decoding locality
if (decoder.bool()) {
AddressItem.locality = decoder.string();
}
// decoding region
if (decoder.bool()) {
AddressItem.region = decoder.string();
}
// decoding postalCode
if (decoder.bool()) {
AddressItem.postalCode = decoder.string();
}
// decoding countryName
if (decoder.bool()) {
AddressItem.countryName = decoder.string();
}
// decoding pref
if (decoder.bool()) {
AddressItem.pref = decoder.bool();
}
return AddressItem;
}
ContactInfoItem.addresses.push(DecodeAddress(decoder));
}
}
// decoding email
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.email = [];
for (let i = 0; i < count; i++) {
function DecodeContactField(decoder) {
let ContactFieldItem = {};
// decoding atype
if (decoder.bool()) {
ContactFieldItem.atype = decoder.string();
}
// decoding value
ContactFieldItem.value = decoder.string();
// decoding pref
if (decoder.bool()) {
ContactFieldItem.pref = decoder.bool();
}
return ContactFieldItem;
}
ContactInfoItem.email.push(DecodeContactField(decoder));
}
}
// decoding url
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.url = [];
for (let i = 0; i < count; i++) {
function DecodeContactField(decoder) {
let ContactFieldItem = {};
// decoding atype
if (decoder.bool()) {
ContactFieldItem.atype = decoder.string();
}
// decoding value
ContactFieldItem.value = decoder.string();
// decoding pref
if (decoder.bool()) {
ContactFieldItem.pref = decoder.bool();
}
return ContactFieldItem;
}
ContactInfoItem.url.push(DecodeContactField(decoder));
}
}
// decoding name
if (decoder.bool()) {
ContactInfoItem.name = decoder.string();
}
// decoding tel
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.tel = [];
for (let i = 0; i < count; i++) {
function DecodeContactTelField(decoder) {
let ContactTelFieldItem = {};
// decoding atype
if (decoder.bool()) {
ContactTelFieldItem.atype = decoder.string();
}
// decoding value
ContactTelFieldItem.value = decoder.string();
// decoding pref
if (decoder.bool()) {
ContactTelFieldItem.pref = decoder.bool();
}
// decoding carrier
if (decoder.bool()) {
ContactTelFieldItem.carrier = decoder.string();
}
return ContactTelFieldItem;
}
ContactInfoItem.tel.push(DecodeContactTelField(decoder));
}
}
// decoding honorificPrefix
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.honorificPrefix = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.honorificPrefix.push(decoder.string());
}
}
// decoding givenName
if (decoder.bool()) {
ContactInfoItem.givenName = decoder.string();
}
// decoding phoneticGivenName
if (decoder.bool()) {
ContactInfoItem.phoneticGivenName = decoder.string();
}
// decoding additionalName
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.additionalName = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.additionalName.push(decoder.string());
}
}
// decoding familyName
if (decoder.bool()) {
ContactInfoItem.familyName = decoder.string();
}
// decoding phoneticFamilyName
if (decoder.bool()) {
ContactInfoItem.phoneticFamilyName = decoder.string();
}
// decoding honorificSuffix
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.honorificSuffix = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.honorificSuffix.push(decoder.string());
}
}
// decoding nickname
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.nickname = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.nickname.push(decoder.string());
}
}
// decoding category
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.category = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.category.push(decoder.string());
}
}
// decoding org
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.org = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.org.push(decoder.string());
}
}
// decoding jobTitle
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.jobTitle = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.jobTitle.push(decoder.string());
}
}
// decoding note
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.note = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.note.push(decoder.string());
}
}
// decoding groups
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.groups = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.groups.push(decoder.string());
}
}
// decoding icePosition
ContactInfoItem.icePosition = decoder.i64();
return ContactInfoItem;
}
result.push(DecodeContactInfo(decoder));
}
} // let count = ... scope
return { success: result }
}
else if (variant == 1) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`NextResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
}

class ContactsFactorySession extends SessionObject {
constructor(object_id, service_id, session) {
super(object_id , session, service_id, ContactsFactoryMessages);
session.track_events(service_id, object_id, this);
}
add(contacts){
return this.call_method("Add", {contacts: contacts});
}
addBlockedNumber(number){
return this.call_method("AddBlockedNumber", {number: number});
}
addGroup(name){
return this.call_method("AddGroup", {name: name});
}
addSpeedDial(dialKey,tel,contactId){
return this.call_method("AddSpeedDial", {dialKey: dialKey,tel: tel,contactId: contactId});
}
alphabetSearch(options){
return this.call_method("AlphabetSearch", {options: options});
}
clearContacts(){
return this.call_method("ClearContacts", {});
}
find(params,batchSize){
return this.call_method("Find", {params: params,batchSize: batchSize});
}
findBlockedNumbers(options){
return this.call_method("FindBlockedNumbers", {options: options});
}
get(id,onlyMainData){
return this.call_method("Get", {id: id,onlyMainData: onlyMainData});
}
getAll(options,batchSize,onlyMainData){
return this.call_method("GetAll", {options: options,batchSize: batchSize,onlyMainData: onlyMainData});
}
getAllBlockedNumbers(){
return this.call_method("GetAllBlockedNumbers", {});
}
getAllGroups(){
return this.call_method("GetAllGroups", {});
}
getAllIce(){
return this.call_method("GetAllIce", {});
}
getContactidsFromGroup(groupId){
return this.call_method("GetContactidsFromGroup", {groupId: groupId});
}
getCount(){
return this.call_method("GetCount", {});
}
getSpeedDials(){
return this.call_method("GetSpeedDials", {});
}
importVcf(vcf){
return this.call_method("ImportVcf", {vcf: vcf});
}
matches(filterByOption,filter,value){
return this.call_method("Matches", {filterByOption: filterByOption,filter: filter,value: value});
}
remove(contactIds){
return this.call_method("Remove", {contactIds: contactIds});
}
removeBlockedNumber(number){
return this.call_method("RemoveBlockedNumber", {number: number});
}
removeGroup(id){
return this.call_method("RemoveGroup", {id: id});
}
removeIce(contactId){
return this.call_method("RemoveIce", {contactId: contactId});
}
removeSpeedDial(dialKey){
return this.call_method("RemoveSpeedDial", {dialKey: dialKey});
}
setIce(contactId,position){
return this.call_method("SetIce", {contactId: contactId,position: position});
}
update(contacts){
return this.call_method("Update", {contacts: contacts});
}
updateGroup(id,name){
return this.call_method("UpdateGroup", {id: id,name: name});
}
updateSpeedDial(dialKey,tel,contactId){
return this.call_method("UpdateSpeedDial", {dialKey: dialKey,tel: tel,contactId: contactId});
}
on_event(event) {
// console.log(`ContactsFactorySession message: ${event}`);
let decoder = new Decoder(event);
let variant = decoder.enum_tag();
// Event #56: BLOCKEDNUMBER_CHANGE
if (variant == 56) {
let result = null;
// decoding <no_name>
function DecodeBlockedNumberChangeEvent(decoder) {
let BlockedNumberChangeEventItem = {};
// decoding reason
BlockedNumberChangeEventItem.reason = decoder.enum_tag();
// decoding number
BlockedNumberChangeEventItem.number = decoder.string();
return BlockedNumberChangeEventItem;
}
result = DecodeBlockedNumberChangeEvent(decoder);
this.dispatchEvent(0, result);
}
// Event #57: CONTACTS_CHANGE
else if (variant == 57) {
let result = null;
// decoding <no_name>
function DecodeContactsChangeEvent(decoder) {
let ContactsChangeEventItem = {};
// decoding reason
ContactsChangeEventItem.reason = decoder.enum_tag();
// decoding contacts
if (decoder.bool()) {
let count = decoder.u64();
ContactsChangeEventItem.contacts = [];
for (let i = 0; i < count; i++) {
function DecodeContactInfo(decoder) {
let ContactInfoItem = {};
// decoding id
if (decoder.bool()) {
ContactInfoItem.id = decoder.string();
}
// decoding published
if (decoder.bool()) {
ContactInfoItem.published = decoder.date();
}
// decoding updated
if (decoder.bool()) {
ContactInfoItem.updated = decoder.date();
}
// decoding bday
if (decoder.bool()) {
ContactInfoItem.bday = decoder.date();
}
// decoding anniversary
if (decoder.bool()) {
ContactInfoItem.anniversary = decoder.date();
}
// decoding sex
if (decoder.bool()) {
ContactInfoItem.sex = decoder.string();
}
// decoding genderIdentity
if (decoder.bool()) {
ContactInfoItem.genderIdentity = decoder.string();
}
// decoding ringtone
if (decoder.bool()) {
ContactInfoItem.ringtone = decoder.string();
}
// decoding photoType
if (decoder.bool()) {
ContactInfoItem.photoType = decoder.string();
}
// decoding photoBlob
if (decoder.bool()) {
ContactInfoItem.photoBlob = decoder.u8_array();
}
// decoding addresses
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.addresses = [];
for (let i = 0; i < count; i++) {
function DecodeAddress(decoder) {
let AddressItem = {};
// decoding atype
if (decoder.bool()) {
AddressItem.atype = decoder.string();
}
// decoding streetAddress
if (decoder.bool()) {
AddressItem.streetAddress = decoder.string();
}
// decoding locality
if (decoder.bool()) {
AddressItem.locality = decoder.string();
}
// decoding region
if (decoder.bool()) {
AddressItem.region = decoder.string();
}
// decoding postalCode
if (decoder.bool()) {
AddressItem.postalCode = decoder.string();
}
// decoding countryName
if (decoder.bool()) {
AddressItem.countryName = decoder.string();
}
// decoding pref
if (decoder.bool()) {
AddressItem.pref = decoder.bool();
}
return AddressItem;
}
ContactInfoItem.addresses.push(DecodeAddress(decoder));
}
}
// decoding email
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.email = [];
for (let i = 0; i < count; i++) {
function DecodeContactField(decoder) {
let ContactFieldItem = {};
// decoding atype
if (decoder.bool()) {
ContactFieldItem.atype = decoder.string();
}
// decoding value
ContactFieldItem.value = decoder.string();
// decoding pref
if (decoder.bool()) {
ContactFieldItem.pref = decoder.bool();
}
return ContactFieldItem;
}
ContactInfoItem.email.push(DecodeContactField(decoder));
}
}
// decoding url
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.url = [];
for (let i = 0; i < count; i++) {
function DecodeContactField(decoder) {
let ContactFieldItem = {};
// decoding atype
if (decoder.bool()) {
ContactFieldItem.atype = decoder.string();
}
// decoding value
ContactFieldItem.value = decoder.string();
// decoding pref
if (decoder.bool()) {
ContactFieldItem.pref = decoder.bool();
}
return ContactFieldItem;
}
ContactInfoItem.url.push(DecodeContactField(decoder));
}
}
// decoding name
if (decoder.bool()) {
ContactInfoItem.name = decoder.string();
}
// decoding tel
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.tel = [];
for (let i = 0; i < count; i++) {
function DecodeContactTelField(decoder) {
let ContactTelFieldItem = {};
// decoding atype
if (decoder.bool()) {
ContactTelFieldItem.atype = decoder.string();
}
// decoding value
ContactTelFieldItem.value = decoder.string();
// decoding pref
if (decoder.bool()) {
ContactTelFieldItem.pref = decoder.bool();
}
// decoding carrier
if (decoder.bool()) {
ContactTelFieldItem.carrier = decoder.string();
}
return ContactTelFieldItem;
}
ContactInfoItem.tel.push(DecodeContactTelField(decoder));
}
}
// decoding honorificPrefix
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.honorificPrefix = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.honorificPrefix.push(decoder.string());
}
}
// decoding givenName
if (decoder.bool()) {
ContactInfoItem.givenName = decoder.string();
}
// decoding phoneticGivenName
if (decoder.bool()) {
ContactInfoItem.phoneticGivenName = decoder.string();
}
// decoding additionalName
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.additionalName = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.additionalName.push(decoder.string());
}
}
// decoding familyName
if (decoder.bool()) {
ContactInfoItem.familyName = decoder.string();
}
// decoding phoneticFamilyName
if (decoder.bool()) {
ContactInfoItem.phoneticFamilyName = decoder.string();
}
// decoding honorificSuffix
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.honorificSuffix = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.honorificSuffix.push(decoder.string());
}
}
// decoding nickname
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.nickname = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.nickname.push(decoder.string());
}
}
// decoding category
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.category = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.category.push(decoder.string());
}
}
// decoding org
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.org = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.org.push(decoder.string());
}
}
// decoding jobTitle
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.jobTitle = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.jobTitle.push(decoder.string());
}
}
// decoding note
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.note = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.note.push(decoder.string());
}
}
// decoding groups
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.groups = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.groups.push(decoder.string());
}
}
// decoding icePosition
ContactInfoItem.icePosition = decoder.i64();
return ContactInfoItem;
}
ContactsChangeEventItem.contacts.push(DecodeContactInfo(decoder));
}
}
return ContactsChangeEventItem;
}
result = DecodeContactsChangeEvent(decoder);
this.dispatchEvent(1, result);
}
// Event #58: GROUP_CHANGE
else if (variant == 58) {
let result = null;
// decoding <no_name>
function DecodeGroupChangeEvent(decoder) {
let GroupChangeEventItem = {};
// decoding reason
GroupChangeEventItem.reason = decoder.enum_tag();
// decoding group
function DecodeGroupInfo(decoder) {
let GroupInfoItem = {};
// decoding id
GroupInfoItem.id = decoder.string();
// decoding name
GroupInfoItem.name = decoder.string();
return GroupInfoItem;
}
GroupChangeEventItem.group = DecodeGroupInfo(decoder);
return GroupChangeEventItem;
}
result = DecodeGroupChangeEvent(decoder);
this.dispatchEvent(2, result);
}
// Event #59: SIM_CONTACT_LOADED
else if (variant == 59) {
let result = null;
// decoding <no_name>
function DecodeSimContactLoadedEvent(decoder) {
let SimContactLoadedEventItem = {};
// decoding removeCount
SimContactLoadedEventItem.removeCount = decoder.i64();
// decoding updateCount
SimContactLoadedEventItem.updateCount = decoder.i64();
return SimContactLoadedEventItem;
}
result = DecodeSimContactLoadedEvent(decoder);
this.dispatchEvent(3, result);
}
// Event #60: SPEEDDIAL_CHANGE
else if (variant == 60) {
let result = null;
// decoding <no_name>
function DecodeSpeedDialChangeEvent(decoder) {
let SpeedDialChangeEventItem = {};
// decoding reason
SpeedDialChangeEventItem.reason = decoder.enum_tag();
// decoding speeddial
function DecodeSpeedDialInfo(decoder) {
let SpeedDialInfoItem = {};
// decoding dialKey
SpeedDialInfoItem.dialKey = decoder.string();
// decoding tel
SpeedDialInfoItem.tel = decoder.string();
// decoding contactId
SpeedDialInfoItem.contactId = decoder.string();
return SpeedDialInfoItem;
}
SpeedDialChangeEventItem.speeddial = DecodeSpeedDialInfo(decoder);
return SpeedDialChangeEventItem;
}
result = DecodeSpeedDialChangeEvent(decoder);
this.dispatchEvent(4, result);
}
else {
 console.error(`Unable to process variant #${variant}`); }
}
}

ContactsFactorySession.prototype.BLOCKEDNUMBER_CHANGE_EVENT = 0;
ContactsFactorySession.prototype.CONTACTS_CHANGE_EVENT = 1;
ContactsFactorySession.prototype.GROUP_CHANGE_EVENT = 2;
ContactsFactorySession.prototype.SIM_CONTACT_LOADED_EVENT = 3;
ContactsFactorySession.prototype.SPEEDDIAL_CHANGE_EVENT = 4;
const ContactsFactoryMessages = {
AddRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(1);
result = result.u64(data.contacts.length);
data.contacts.forEach(data => {
// ContactInfo
function EncodeContactInfo(ContactInfoItem, result) {
result = result.bool(ContactInfoItem.id !== undefined);
if (ContactInfoItem.id !== undefined) {
result = result.string(ContactInfoItem.id);
}
result = result.bool(ContactInfoItem.published !== undefined);
if (ContactInfoItem.published !== undefined) {
result = result.date(ContactInfoItem.published);
}
result = result.bool(ContactInfoItem.updated !== undefined);
if (ContactInfoItem.updated !== undefined) {
result = result.date(ContactInfoItem.updated);
}
result = result.bool(ContactInfoItem.bday !== undefined);
if (ContactInfoItem.bday !== undefined) {
result = result.date(ContactInfoItem.bday);
}
result = result.bool(ContactInfoItem.anniversary !== undefined);
if (ContactInfoItem.anniversary !== undefined) {
result = result.date(ContactInfoItem.anniversary);
}
result = result.bool(ContactInfoItem.sex !== undefined);
if (ContactInfoItem.sex !== undefined) {
result = result.string(ContactInfoItem.sex);
}
result = result.bool(ContactInfoItem.genderIdentity !== undefined);
if (ContactInfoItem.genderIdentity !== undefined) {
result = result.string(ContactInfoItem.genderIdentity);
}
result = result.bool(ContactInfoItem.ringtone !== undefined);
if (ContactInfoItem.ringtone !== undefined) {
result = result.string(ContactInfoItem.ringtone);
}
result = result.bool(ContactInfoItem.photoType !== undefined);
if (ContactInfoItem.photoType !== undefined) {
result = result.string(ContactInfoItem.photoType);
}
result = result.bool(ContactInfoItem.photoBlob !== undefined);
if (ContactInfoItem.photoBlob !== undefined) {
result = result.u8_array(ContactInfoItem.photoBlob);
}
result = result.bool(ContactInfoItem.addresses !== undefined && ContactInfoItem.addresses.length > 0);
if (ContactInfoItem.addresses !== undefined && ContactInfoItem.addresses.length > 0) {
result = result.u64(ContactInfoItem.addresses.length);
ContactInfoItem.addresses.forEach(ContactInfoItem => {
// Address
function EncodeAddress(AddressItem, result) {
result = result.bool(AddressItem.atype !== undefined);
if (AddressItem.atype !== undefined) {
result = result.string(AddressItem.atype);
}
result = result.bool(AddressItem.streetAddress !== undefined);
if (AddressItem.streetAddress !== undefined) {
result = result.string(AddressItem.streetAddress);
}
result = result.bool(AddressItem.locality !== undefined);
if (AddressItem.locality !== undefined) {
result = result.string(AddressItem.locality);
}
result = result.bool(AddressItem.region !== undefined);
if (AddressItem.region !== undefined) {
result = result.string(AddressItem.region);
}
result = result.bool(AddressItem.postalCode !== undefined);
if (AddressItem.postalCode !== undefined) {
result = result.string(AddressItem.postalCode);
}
result = result.bool(AddressItem.countryName !== undefined);
if (AddressItem.countryName !== undefined) {
result = result.string(AddressItem.countryName);
}
result = result.bool(AddressItem.pref !== undefined);
if (AddressItem.pref !== undefined) {
result = result.bool(AddressItem.pref);
}
return result;
}
result = EncodeAddress(ContactInfoItem, result);
});
 }
result = result.bool(ContactInfoItem.email !== undefined && ContactInfoItem.email.length > 0);
if (ContactInfoItem.email !== undefined && ContactInfoItem.email.length > 0) {
result = result.u64(ContactInfoItem.email.length);
ContactInfoItem.email.forEach(ContactInfoItem => {
// ContactField
function EncodeContactField(ContactFieldItem, result) {
result = result.bool(ContactFieldItem.atype !== undefined);
if (ContactFieldItem.atype !== undefined) {
result = result.string(ContactFieldItem.atype);
}
result = result.string(ContactFieldItem.value);
result = result.bool(ContactFieldItem.pref !== undefined);
if (ContactFieldItem.pref !== undefined) {
result = result.bool(ContactFieldItem.pref);
}
return result;
}
result = EncodeContactField(ContactInfoItem, result);
});
 }
result = result.bool(ContactInfoItem.url !== undefined && ContactInfoItem.url.length > 0);
if (ContactInfoItem.url !== undefined && ContactInfoItem.url.length > 0) {
result = result.u64(ContactInfoItem.url.length);
ContactInfoItem.url.forEach(ContactInfoItem => {
// ContactField
function EncodeContactField(ContactFieldItem, result) {
result = result.bool(ContactFieldItem.atype !== undefined);
if (ContactFieldItem.atype !== undefined) {
result = result.string(ContactFieldItem.atype);
}
result = result.string(ContactFieldItem.value);
result = result.bool(ContactFieldItem.pref !== undefined);
if (ContactFieldItem.pref !== undefined) {
result = result.bool(ContactFieldItem.pref);
}
return result;
}
result = EncodeContactField(ContactInfoItem, result);
});
 }
result = result.bool(ContactInfoItem.name !== undefined);
if (ContactInfoItem.name !== undefined) {
result = result.string(ContactInfoItem.name);
}
result = result.bool(ContactInfoItem.tel !== undefined && ContactInfoItem.tel.length > 0);
if (ContactInfoItem.tel !== undefined && ContactInfoItem.tel.length > 0) {
result = result.u64(ContactInfoItem.tel.length);
ContactInfoItem.tel.forEach(ContactInfoItem => {
// ContactTelField
function EncodeContactTelField(ContactTelFieldItem, result) {
result = result.bool(ContactTelFieldItem.atype !== undefined);
if (ContactTelFieldItem.atype !== undefined) {
result = result.string(ContactTelFieldItem.atype);
}
result = result.string(ContactTelFieldItem.value);
result = result.bool(ContactTelFieldItem.pref !== undefined);
if (ContactTelFieldItem.pref !== undefined) {
result = result.bool(ContactTelFieldItem.pref);
}
result = result.bool(ContactTelFieldItem.carrier !== undefined);
if (ContactTelFieldItem.carrier !== undefined) {
result = result.string(ContactTelFieldItem.carrier);
}
return result;
}
result = EncodeContactTelField(ContactInfoItem, result);
});
 }
result = result.bool(ContactInfoItem.honorificPrefix !== undefined && ContactInfoItem.honorificPrefix.length > 0);
if (ContactInfoItem.honorificPrefix !== undefined && ContactInfoItem.honorificPrefix.length > 0) {
result = result.u64(ContactInfoItem.honorificPrefix.length);
ContactInfoItem.honorificPrefix.forEach(item => {
result = result.string(item);
});
 }
result = result.bool(ContactInfoItem.givenName !== undefined);
if (ContactInfoItem.givenName !== undefined) {
result = result.string(ContactInfoItem.givenName);
}
result = result.bool(ContactInfoItem.phoneticGivenName !== undefined);
if (ContactInfoItem.phoneticGivenName !== undefined) {
result = result.string(ContactInfoItem.phoneticGivenName);
}
result = result.bool(ContactInfoItem.additionalName !== undefined && ContactInfoItem.additionalName.length > 0);
if (ContactInfoItem.additionalName !== undefined && ContactInfoItem.additionalName.length > 0) {
result = result.u64(ContactInfoItem.additionalName.length);
ContactInfoItem.additionalName.forEach(item => {
result = result.string(item);
});
 }
result = result.bool(ContactInfoItem.familyName !== undefined);
if (ContactInfoItem.familyName !== undefined) {
result = result.string(ContactInfoItem.familyName);
}
result = result.bool(ContactInfoItem.phoneticFamilyName !== undefined);
if (ContactInfoItem.phoneticFamilyName !== undefined) {
result = result.string(ContactInfoItem.phoneticFamilyName);
}
result = result.bool(ContactInfoItem.honorificSuffix !== undefined && ContactInfoItem.honorificSuffix.length > 0);
if (ContactInfoItem.honorificSuffix !== undefined && ContactInfoItem.honorificSuffix.length > 0) {
result = result.u64(ContactInfoItem.honorificSuffix.length);
ContactInfoItem.honorificSuffix.forEach(item => {
result = result.string(item);
});
 }
result = result.bool(ContactInfoItem.nickname !== undefined && ContactInfoItem.nickname.length > 0);
if (ContactInfoItem.nickname !== undefined && ContactInfoItem.nickname.length > 0) {
result = result.u64(ContactInfoItem.nickname.length);
ContactInfoItem.nickname.forEach(item => {
result = result.string(item);
});
 }
result = result.bool(ContactInfoItem.category !== undefined && ContactInfoItem.category.length > 0);
if (ContactInfoItem.category !== undefined && ContactInfoItem.category.length > 0) {
result = result.u64(ContactInfoItem.category.length);
ContactInfoItem.category.forEach(item => {
result = result.string(item);
});
 }
result = result.bool(ContactInfoItem.org !== undefined && ContactInfoItem.org.length > 0);
if (ContactInfoItem.org !== undefined && ContactInfoItem.org.length > 0) {
result = result.u64(ContactInfoItem.org.length);
ContactInfoItem.org.forEach(item => {
result = result.string(item);
});
 }
result = result.bool(ContactInfoItem.jobTitle !== undefined && ContactInfoItem.jobTitle.length > 0);
if (ContactInfoItem.jobTitle !== undefined && ContactInfoItem.jobTitle.length > 0) {
result = result.u64(ContactInfoItem.jobTitle.length);
ContactInfoItem.jobTitle.forEach(item => {
result = result.string(item);
});
 }
result = result.bool(ContactInfoItem.note !== undefined && ContactInfoItem.note.length > 0);
if (ContactInfoItem.note !== undefined && ContactInfoItem.note.length > 0) {
result = result.u64(ContactInfoItem.note.length);
ContactInfoItem.note.forEach(item => {
result = result.string(item);
});
 }
result = result.bool(ContactInfoItem.groups !== undefined && ContactInfoItem.groups.length > 0);
if (ContactInfoItem.groups !== undefined && ContactInfoItem.groups.length > 0) {
result = result.u64(ContactInfoItem.groups.length);
ContactInfoItem.groups.forEach(item => {
result = result.string(item);
});
 }
result = result.i64(ContactInfoItem.icePosition);
return result;
}
result = EncodeContactInfo(data, result);
});
return result.value();
}
},
AddResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 2) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 3) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`AddResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
AddBlockedNumberRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(2);
result = result.string(data.number);
return result.value();
}
},
AddBlockedNumberResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 4) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 5) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`AddBlockedNumberResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
AddGroupRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(3);
result = result.string(data.name);
return result.value();
}
},
AddGroupResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 6) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 7) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`AddGroupResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
AddSpeedDialRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(4);
result = result.string(data.dialKey);
result = result.string(data.tel);
result = result.string(data.contactId);
return result.value();
}
},
AddSpeedDialResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 8) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 9) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`AddSpeedDialResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
AlphabetSearchRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(5);
// AlphabetSearchOptions
function EncodeAlphabetSearchOptions(AlphabetSearchOptionsItem, result) {
result = result.string(AlphabetSearchOptionsItem.filterValue);
result = result.i64(AlphabetSearchOptionsItem.batchSize);
result = result.bool(AlphabetSearchOptionsItem.filterLimit !== undefined);
if (AlphabetSearchOptionsItem.filterLimit !== undefined) {
result = result.i64(AlphabetSearchOptionsItem.filterLimit);
}
result = result.bool(AlphabetSearchOptionsItem.onlyMainData !== undefined);
if (AlphabetSearchOptionsItem.onlyMainData !== undefined) {
result = result.bool(AlphabetSearchOptionsItem.onlyMainData);
}
return result;
}
result = EncodeAlphabetSearchOptions(data.options, result);
return result.value();
}
},
AlphabetSearchResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 10) {
// Success
let result = null;
// decoding <no_name>
result = new ContactCursorSession(decoder.u32(), service_id, session);return { success: result }
}
else if (variant == 11) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`AlphabetSearchResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
ClearContactsRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(6);
return result.value();
}
},
ClearContactsResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 12) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 13) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`ClearContactsResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
FindRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(7);
// ContactFindSortOptions
function EncodeContactFindSortOptions(ContactFindSortOptionsItem, result) {
result = result.bool(ContactFindSortOptionsItem.sortBy !== undefined);
if (ContactFindSortOptionsItem.sortBy !== undefined) {
result = result.enum_tag(ContactFindSortOptionsItem.sortBy);
}
result = result.bool(ContactFindSortOptionsItem.sortOrder !== undefined);
if (ContactFindSortOptionsItem.sortOrder !== undefined) {
result = result.enum_tag(ContactFindSortOptionsItem.sortOrder);
}
result = result.bool(ContactFindSortOptionsItem.sortLanguage !== undefined);
if (ContactFindSortOptionsItem.sortLanguage !== undefined) {
result = result.string(ContactFindSortOptionsItem.sortLanguage);
}
result = result.string(ContactFindSortOptionsItem.filterValue);
result = result.enum_tag(ContactFindSortOptionsItem.filterOption);
result = result.u64(ContactFindSortOptionsItem.filterBy.length);
ContactFindSortOptionsItem.filterBy.forEach(item => {
result = result.enum_tag(item);
});
result = result.bool(ContactFindSortOptionsItem.onlyMainData !== undefined);
if (ContactFindSortOptionsItem.onlyMainData !== undefined) {
result = result.bool(ContactFindSortOptionsItem.onlyMainData);
}
return result;
}
result = EncodeContactFindSortOptions(data.params, result);
result = result.i64(data.batchSize);
return result.value();
}
},
FindResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 14) {
// Success
let result = null;
// decoding <no_name>
result = new ContactCursorSession(decoder.u32(), service_id, session);return { success: result }
}
else if (variant == 15) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`FindResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
FindBlockedNumbersRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(8);
// BlockedNumberFindOptions
function EncodeBlockedNumberFindOptions(BlockedNumberFindOptionsItem, result) {
result = result.string(BlockedNumberFindOptionsItem.filterValue);
result = result.enum_tag(BlockedNumberFindOptionsItem.filterOption);
return result;
}
result = EncodeBlockedNumberFindOptions(data.options, result);
return result.value();
}
},
FindBlockedNumbersResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 16) {
// Success
let result = null;
// decoding <no_name>
if (decoder.bool()) {
let count = decoder.u64();
result = [];
for (let i = 0; i < count; i++) {
result.push(decoder.string());
}
}
return { success: result }
}
else if (variant == 17) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`FindBlockedNumbersResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(9);
result = result.string(data.id);
result = result.bool(data.onlyMainData);
return result.value();
}
},
GetResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 18) {
// Success
let result = null;
// decoding <no_name>
function DecodeContactInfo(decoder) {
let ContactInfoItem = {};
// decoding id
if (decoder.bool()) {
ContactInfoItem.id = decoder.string();
}
// decoding published
if (decoder.bool()) {
ContactInfoItem.published = decoder.date();
}
// decoding updated
if (decoder.bool()) {
ContactInfoItem.updated = decoder.date();
}
// decoding bday
if (decoder.bool()) {
ContactInfoItem.bday = decoder.date();
}
// decoding anniversary
if (decoder.bool()) {
ContactInfoItem.anniversary = decoder.date();
}
// decoding sex
if (decoder.bool()) {
ContactInfoItem.sex = decoder.string();
}
// decoding genderIdentity
if (decoder.bool()) {
ContactInfoItem.genderIdentity = decoder.string();
}
// decoding ringtone
if (decoder.bool()) {
ContactInfoItem.ringtone = decoder.string();
}
// decoding photoType
if (decoder.bool()) {
ContactInfoItem.photoType = decoder.string();
}
// decoding photoBlob
if (decoder.bool()) {
ContactInfoItem.photoBlob = decoder.u8_array();
}
// decoding addresses
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.addresses = [];
for (let i = 0; i < count; i++) {
function DecodeAddress(decoder) {
let AddressItem = {};
// decoding atype
if (decoder.bool()) {
AddressItem.atype = decoder.string();
}
// decoding streetAddress
if (decoder.bool()) {
AddressItem.streetAddress = decoder.string();
}
// decoding locality
if (decoder.bool()) {
AddressItem.locality = decoder.string();
}
// decoding region
if (decoder.bool()) {
AddressItem.region = decoder.string();
}
// decoding postalCode
if (decoder.bool()) {
AddressItem.postalCode = decoder.string();
}
// decoding countryName
if (decoder.bool()) {
AddressItem.countryName = decoder.string();
}
// decoding pref
if (decoder.bool()) {
AddressItem.pref = decoder.bool();
}
return AddressItem;
}
ContactInfoItem.addresses.push(DecodeAddress(decoder));
}
}
// decoding email
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.email = [];
for (let i = 0; i < count; i++) {
function DecodeContactField(decoder) {
let ContactFieldItem = {};
// decoding atype
if (decoder.bool()) {
ContactFieldItem.atype = decoder.string();
}
// decoding value
ContactFieldItem.value = decoder.string();
// decoding pref
if (decoder.bool()) {
ContactFieldItem.pref = decoder.bool();
}
return ContactFieldItem;
}
ContactInfoItem.email.push(DecodeContactField(decoder));
}
}
// decoding url
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.url = [];
for (let i = 0; i < count; i++) {
function DecodeContactField(decoder) {
let ContactFieldItem = {};
// decoding atype
if (decoder.bool()) {
ContactFieldItem.atype = decoder.string();
}
// decoding value
ContactFieldItem.value = decoder.string();
// decoding pref
if (decoder.bool()) {
ContactFieldItem.pref = decoder.bool();
}
return ContactFieldItem;
}
ContactInfoItem.url.push(DecodeContactField(decoder));
}
}
// decoding name
if (decoder.bool()) {
ContactInfoItem.name = decoder.string();
}
// decoding tel
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.tel = [];
for (let i = 0; i < count; i++) {
function DecodeContactTelField(decoder) {
let ContactTelFieldItem = {};
// decoding atype
if (decoder.bool()) {
ContactTelFieldItem.atype = decoder.string();
}
// decoding value
ContactTelFieldItem.value = decoder.string();
// decoding pref
if (decoder.bool()) {
ContactTelFieldItem.pref = decoder.bool();
}
// decoding carrier
if (decoder.bool()) {
ContactTelFieldItem.carrier = decoder.string();
}
return ContactTelFieldItem;
}
ContactInfoItem.tel.push(DecodeContactTelField(decoder));
}
}
// decoding honorificPrefix
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.honorificPrefix = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.honorificPrefix.push(decoder.string());
}
}
// decoding givenName
if (decoder.bool()) {
ContactInfoItem.givenName = decoder.string();
}
// decoding phoneticGivenName
if (decoder.bool()) {
ContactInfoItem.phoneticGivenName = decoder.string();
}
// decoding additionalName
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.additionalName = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.additionalName.push(decoder.string());
}
}
// decoding familyName
if (decoder.bool()) {
ContactInfoItem.familyName = decoder.string();
}
// decoding phoneticFamilyName
if (decoder.bool()) {
ContactInfoItem.phoneticFamilyName = decoder.string();
}
// decoding honorificSuffix
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.honorificSuffix = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.honorificSuffix.push(decoder.string());
}
}
// decoding nickname
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.nickname = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.nickname.push(decoder.string());
}
}
// decoding category
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.category = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.category.push(decoder.string());
}
}
// decoding org
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.org = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.org.push(decoder.string());
}
}
// decoding jobTitle
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.jobTitle = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.jobTitle.push(decoder.string());
}
}
// decoding note
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.note = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.note.push(decoder.string());
}
}
// decoding groups
if (decoder.bool()) {
let count = decoder.u64();
ContactInfoItem.groups = [];
for (let i = 0; i < count; i++) {
ContactInfoItem.groups.push(decoder.string());
}
}
// decoding icePosition
ContactInfoItem.icePosition = decoder.i64();
return ContactInfoItem;
}
result = DecodeContactInfo(decoder);
return { success: result }
}
else if (variant == 19) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetAllRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(10);
// ContactSortOptions
function EncodeContactSortOptions(ContactSortOptionsItem, result) {
result = result.enum_tag(ContactSortOptionsItem.sortBy);
result = result.enum_tag(ContactSortOptionsItem.sortOrder);
result = result.bool(ContactSortOptionsItem.sortLanguage !== undefined);
if (ContactSortOptionsItem.sortLanguage !== undefined) {
result = result.string(ContactSortOptionsItem.sortLanguage);
}
return result;
}
result = EncodeContactSortOptions(data.options, result);
result = result.i64(data.batchSize);
result = result.bool(data.onlyMainData);
return result.value();
}
},
GetAllResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 20) {
// Success
let result = null;
// decoding <no_name>
result = new ContactCursorSession(decoder.u32(), service_id, session);return { success: result }
}
else if (variant == 21) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetAllResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetAllBlockedNumbersRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(11);
return result.value();
}
},
GetAllBlockedNumbersResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 22) {
// Success
let result = null;
// decoding <no_name>
if (decoder.bool()) {
let count = decoder.u64();
result = [];
for (let i = 0; i < count; i++) {
result.push(decoder.string());
}
}
return { success: result }
}
else if (variant == 23) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetAllBlockedNumbersResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetAllGroupsRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(12);
return result.value();
}
},
GetAllGroupsResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 24) {
// Success
let result = null;
// decoding <no_name>
if (decoder.bool()) {
let count = decoder.u64();
result = [];
for (let i = 0; i < count; i++) {
function DecodeGroupInfo(decoder) {
let GroupInfoItem = {};
// decoding id
GroupInfoItem.id = decoder.string();
// decoding name
GroupInfoItem.name = decoder.string();
return GroupInfoItem;
}
result.push(DecodeGroupInfo(decoder));
}
}
return { success: result }
}
else if (variant == 25) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetAllGroupsResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetAllIceRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(13);
return result.value();
}
},
GetAllIceResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 26) {
// Success
let result = null;
// decoding <no_name>
if (decoder.bool()) {
let count = decoder.u64();
result = [];
for (let i = 0; i < count; i++) {
function DecodeIceInfo(decoder) {
let IceInfoItem = {};
// decoding position
IceInfoItem.position = decoder.i64();
// decoding contactId
IceInfoItem.contactId = decoder.string();
return IceInfoItem;
}
result.push(DecodeIceInfo(decoder));
}
}
return { success: result }
}
else if (variant == 27) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetAllIceResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetContactidsFromGroupRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(14);
result = result.string(data.groupId);
return result.value();
}
},
GetContactidsFromGroupResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 28) {
// Success
let result = null;
// decoding <no_name>
if (decoder.bool()) {
let count = decoder.u64();
result = [];
for (let i = 0; i < count; i++) {
result.push(decoder.string());
}
}
return { success: result }
}
else if (variant == 29) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetContactidsFromGroupResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetCountRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(15);
return result.value();
}
},
GetCountResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 30) {
// Success
let result = null;
// decoding <no_name>
result = decoder.i64();
return { success: result }
}
else if (variant == 31) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetCountResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetSpeedDialsRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(16);
return result.value();
}
},
GetSpeedDialsResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 32) {
// Success
let result = null;
// decoding <no_name>
if (decoder.bool()) {
let count = decoder.u64();
result = [];
for (let i = 0; i < count; i++) {
function DecodeSpeedDialInfo(decoder) {
let SpeedDialInfoItem = {};
// decoding dialKey
SpeedDialInfoItem.dialKey = decoder.string();
// decoding tel
SpeedDialInfoItem.tel = decoder.string();
// decoding contactId
SpeedDialInfoItem.contactId = decoder.string();
return SpeedDialInfoItem;
}
result.push(DecodeSpeedDialInfo(decoder));
}
}
return { success: result }
}
else if (variant == 33) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetSpeedDialsResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
ImportVcfRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(17);
result = result.string(data.vcf);
return result.value();
}
},
ImportVcfResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 34) {
// Success
let result = null;
// decoding <no_name>
result = decoder.i64();
return { success: result }
}
else if (variant == 35) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`ImportVcfResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
MatchesRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(18);
result = result.enum_tag(data.filterByOption);
result = result.enum_tag(data.filter);
result = result.string(data.value);
return result.value();
}
},
MatchesResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 36) {
// Success
let result = null;
// decoding <no_name>
result = decoder.bool();
return { success: result }
}
else if (variant == 37) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`MatchesResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
RemoveRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(19);
result = result.u64(data.contactIds.length);
data.contactIds.forEach(item => {
result = result.string(item);
});
return result.value();
}
},
RemoveResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 38) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 39) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`RemoveResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
RemoveBlockedNumberRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(20);
result = result.string(data.number);
return result.value();
}
},
RemoveBlockedNumberResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 40) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 41) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`RemoveBlockedNumberResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
RemoveGroupRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(21);
result = result.string(data.id);
return result.value();
}
},
RemoveGroupResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 42) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 43) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`RemoveGroupResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
RemoveIceRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(22);
result = result.string(data.contactId);
return result.value();
}
},
RemoveIceResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 44) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 45) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`RemoveIceResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
RemoveSpeedDialRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(23);
result = result.string(data.dialKey);
return result.value();
}
},
RemoveSpeedDialResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 46) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 47) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`RemoveSpeedDialResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SetIceRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(24);
result = result.string(data.contactId);
result = result.i64(data.position);
return result.value();
}
},
SetIceResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 48) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 49) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`SetIceResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
UpdateRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(25);
result = result.u64(data.contacts.length);
data.contacts.forEach(data => {
// ContactInfo
function EncodeContactInfo(ContactInfoItem, result) {
result = result.bool(ContactInfoItem.id !== undefined);
if (ContactInfoItem.id !== undefined) {
result = result.string(ContactInfoItem.id);
}
result = result.bool(ContactInfoItem.published !== undefined);
if (ContactInfoItem.published !== undefined) {
result = result.date(ContactInfoItem.published);
}
result = result.bool(ContactInfoItem.updated !== undefined);
if (ContactInfoItem.updated !== undefined) {
result = result.date(ContactInfoItem.updated);
}
result = result.bool(ContactInfoItem.bday !== undefined);
if (ContactInfoItem.bday !== undefined) {
result = result.date(ContactInfoItem.bday);
}
result = result.bool(ContactInfoItem.anniversary !== undefined);
if (ContactInfoItem.anniversary !== undefined) {
result = result.date(ContactInfoItem.anniversary);
}
result = result.bool(ContactInfoItem.sex !== undefined);
if (ContactInfoItem.sex !== undefined) {
result = result.string(ContactInfoItem.sex);
}
result = result.bool(ContactInfoItem.genderIdentity !== undefined);
if (ContactInfoItem.genderIdentity !== undefined) {
result = result.string(ContactInfoItem.genderIdentity);
}
result = result.bool(ContactInfoItem.ringtone !== undefined);
if (ContactInfoItem.ringtone !== undefined) {
result = result.string(ContactInfoItem.ringtone);
}
result = result.bool(ContactInfoItem.photoType !== undefined);
if (ContactInfoItem.photoType !== undefined) {
result = result.string(ContactInfoItem.photoType);
}
result = result.bool(ContactInfoItem.photoBlob !== undefined);
if (ContactInfoItem.photoBlob !== undefined) {
result = result.u8_array(ContactInfoItem.photoBlob);
}
result = result.bool(ContactInfoItem.addresses !== undefined && ContactInfoItem.addresses.length > 0);
if (ContactInfoItem.addresses !== undefined && ContactInfoItem.addresses.length > 0) {
result = result.u64(ContactInfoItem.addresses.length);
ContactInfoItem.addresses.forEach(ContactInfoItem => {
// Address
function EncodeAddress(AddressItem, result) {
result = result.bool(AddressItem.atype !== undefined);
if (AddressItem.atype !== undefined) {
result = result.string(AddressItem.atype);
}
result = result.bool(AddressItem.streetAddress !== undefined);
if (AddressItem.streetAddress !== undefined) {
result = result.string(AddressItem.streetAddress);
}
result = result.bool(AddressItem.locality !== undefined);
if (AddressItem.locality !== undefined) {
result = result.string(AddressItem.locality);
}
result = result.bool(AddressItem.region !== undefined);
if (AddressItem.region !== undefined) {
result = result.string(AddressItem.region);
}
result = result.bool(AddressItem.postalCode !== undefined);
if (AddressItem.postalCode !== undefined) {
result = result.string(AddressItem.postalCode);
}
result = result.bool(AddressItem.countryName !== undefined);
if (AddressItem.countryName !== undefined) {
result = result.string(AddressItem.countryName);
}
result = result.bool(AddressItem.pref !== undefined);
if (AddressItem.pref !== undefined) {
result = result.bool(AddressItem.pref);
}
return result;
}
result = EncodeAddress(ContactInfoItem, result);
});
 }
result = result.bool(ContactInfoItem.email !== undefined && ContactInfoItem.email.length > 0);
if (ContactInfoItem.email !== undefined && ContactInfoItem.email.length > 0) {
result = result.u64(ContactInfoItem.email.length);
ContactInfoItem.email.forEach(ContactInfoItem => {
// ContactField
function EncodeContactField(ContactFieldItem, result) {
result = result.bool(ContactFieldItem.atype !== undefined);
if (ContactFieldItem.atype !== undefined) {
result = result.string(ContactFieldItem.atype);
}
result = result.string(ContactFieldItem.value);
result = result.bool(ContactFieldItem.pref !== undefined);
if (ContactFieldItem.pref !== undefined) {
result = result.bool(ContactFieldItem.pref);
}
return result;
}
result = EncodeContactField(ContactInfoItem, result);
});
 }
result = result.bool(ContactInfoItem.url !== undefined && ContactInfoItem.url.length > 0);
if (ContactInfoItem.url !== undefined && ContactInfoItem.url.length > 0) {
result = result.u64(ContactInfoItem.url.length);
ContactInfoItem.url.forEach(ContactInfoItem => {
// ContactField
function EncodeContactField(ContactFieldItem, result) {
result = result.bool(ContactFieldItem.atype !== undefined);
if (ContactFieldItem.atype !== undefined) {
result = result.string(ContactFieldItem.atype);
}
result = result.string(ContactFieldItem.value);
result = result.bool(ContactFieldItem.pref !== undefined);
if (ContactFieldItem.pref !== undefined) {
result = result.bool(ContactFieldItem.pref);
}
return result;
}
result = EncodeContactField(ContactInfoItem, result);
});
 }
result = result.bool(ContactInfoItem.name !== undefined);
if (ContactInfoItem.name !== undefined) {
result = result.string(ContactInfoItem.name);
}
result = result.bool(ContactInfoItem.tel !== undefined && ContactInfoItem.tel.length > 0);
if (ContactInfoItem.tel !== undefined && ContactInfoItem.tel.length > 0) {
result = result.u64(ContactInfoItem.tel.length);
ContactInfoItem.tel.forEach(ContactInfoItem => {
// ContactTelField
function EncodeContactTelField(ContactTelFieldItem, result) {
result = result.bool(ContactTelFieldItem.atype !== undefined);
if (ContactTelFieldItem.atype !== undefined) {
result = result.string(ContactTelFieldItem.atype);
}
result = result.string(ContactTelFieldItem.value);
result = result.bool(ContactTelFieldItem.pref !== undefined);
if (ContactTelFieldItem.pref !== undefined) {
result = result.bool(ContactTelFieldItem.pref);
}
result = result.bool(ContactTelFieldItem.carrier !== undefined);
if (ContactTelFieldItem.carrier !== undefined) {
result = result.string(ContactTelFieldItem.carrier);
}
return result;
}
result = EncodeContactTelField(ContactInfoItem, result);
});
 }
result = result.bool(ContactInfoItem.honorificPrefix !== undefined && ContactInfoItem.honorificPrefix.length > 0);
if (ContactInfoItem.honorificPrefix !== undefined && ContactInfoItem.honorificPrefix.length > 0) {
result = result.u64(ContactInfoItem.honorificPrefix.length);
ContactInfoItem.honorificPrefix.forEach(item => {
result = result.string(item);
});
 }
result = result.bool(ContactInfoItem.givenName !== undefined);
if (ContactInfoItem.givenName !== undefined) {
result = result.string(ContactInfoItem.givenName);
}
result = result.bool(ContactInfoItem.phoneticGivenName !== undefined);
if (ContactInfoItem.phoneticGivenName !== undefined) {
result = result.string(ContactInfoItem.phoneticGivenName);
}
result = result.bool(ContactInfoItem.additionalName !== undefined && ContactInfoItem.additionalName.length > 0);
if (ContactInfoItem.additionalName !== undefined && ContactInfoItem.additionalName.length > 0) {
result = result.u64(ContactInfoItem.additionalName.length);
ContactInfoItem.additionalName.forEach(item => {
result = result.string(item);
});
 }
result = result.bool(ContactInfoItem.familyName !== undefined);
if (ContactInfoItem.familyName !== undefined) {
result = result.string(ContactInfoItem.familyName);
}
result = result.bool(ContactInfoItem.phoneticFamilyName !== undefined);
if (ContactInfoItem.phoneticFamilyName !== undefined) {
result = result.string(ContactInfoItem.phoneticFamilyName);
}
result = result.bool(ContactInfoItem.honorificSuffix !== undefined && ContactInfoItem.honorificSuffix.length > 0);
if (ContactInfoItem.honorificSuffix !== undefined && ContactInfoItem.honorificSuffix.length > 0) {
result = result.u64(ContactInfoItem.honorificSuffix.length);
ContactInfoItem.honorificSuffix.forEach(item => {
result = result.string(item);
});
 }
result = result.bool(ContactInfoItem.nickname !== undefined && ContactInfoItem.nickname.length > 0);
if (ContactInfoItem.nickname !== undefined && ContactInfoItem.nickname.length > 0) {
result = result.u64(ContactInfoItem.nickname.length);
ContactInfoItem.nickname.forEach(item => {
result = result.string(item);
});
 }
result = result.bool(ContactInfoItem.category !== undefined && ContactInfoItem.category.length > 0);
if (ContactInfoItem.category !== undefined && ContactInfoItem.category.length > 0) {
result = result.u64(ContactInfoItem.category.length);
ContactInfoItem.category.forEach(item => {
result = result.string(item);
});
 }
result = result.bool(ContactInfoItem.org !== undefined && ContactInfoItem.org.length > 0);
if (ContactInfoItem.org !== undefined && ContactInfoItem.org.length > 0) {
result = result.u64(ContactInfoItem.org.length);
ContactInfoItem.org.forEach(item => {
result = result.string(item);
});
 }
result = result.bool(ContactInfoItem.jobTitle !== undefined && ContactInfoItem.jobTitle.length > 0);
if (ContactInfoItem.jobTitle !== undefined && ContactInfoItem.jobTitle.length > 0) {
result = result.u64(ContactInfoItem.jobTitle.length);
ContactInfoItem.jobTitle.forEach(item => {
result = result.string(item);
});
 }
result = result.bool(ContactInfoItem.note !== undefined && ContactInfoItem.note.length > 0);
if (ContactInfoItem.note !== undefined && ContactInfoItem.note.length > 0) {
result = result.u64(ContactInfoItem.note.length);
ContactInfoItem.note.forEach(item => {
result = result.string(item);
});
 }
result = result.bool(ContactInfoItem.groups !== undefined && ContactInfoItem.groups.length > 0);
if (ContactInfoItem.groups !== undefined && ContactInfoItem.groups.length > 0) {
result = result.u64(ContactInfoItem.groups.length);
ContactInfoItem.groups.forEach(item => {
result = result.string(item);
});
 }
result = result.i64(ContactInfoItem.icePosition);
return result;
}
result = EncodeContactInfo(data, result);
});
return result.value();
}
},
UpdateResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 50) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 51) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`UpdateResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
UpdateGroupRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(26);
result = result.string(data.id);
result = result.string(data.name);
return result.value();
}
},
UpdateGroupResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 52) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 53) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`UpdateGroupResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
UpdateSpeedDialRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(27);
result = result.string(data.dialKey);
result = result.string(data.tel);
result = result.string(data.contactId);
return result.value();
}
},
UpdateSpeedDialResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 54) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 55) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`UpdateSpeedDialResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
}

export const ContactsManager = {
            get: (session) => {
                return Services.get("ContactsManager", "a7ab5919f6ff24f594d94ce1e98aae136fb19fbc4c11af93c51b76bb8453d", session).then((service_id) => {
                    session.registerService(service_id, "ContactsManager");
                    // object_id is always 0 for the service itself.
                    return new ContactsFactorySession(0, service_id, session);
                });
            },
        };
function wrapBlob(blob) {
            let btype = blob.type;
            return blob.arrayBuffer().then(data => {
                return { __isblob__: true, data: new Uint8Array(data), type: btype }
            });
        }