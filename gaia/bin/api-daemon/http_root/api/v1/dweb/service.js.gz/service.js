// This file is generated. Do not edit.
// @generated
import Services from '../shared/services.js';
import SessionObject from '../shared/sessionobject.js';
import {Encoder, Decoder, wrapBlob} from '../shared/bincode.js';
export const DidError = {
NAME_ALREADY_EXISTS:0,
UNKNOWN_DID:1,
INTERNAL_ERROR:2,
}

export const UcanError = {
NO_UI_PROVIDER:0,
INTERNAL_ERROR:1,
INVALID_AUDIENCE:2,
INVALID_TOKEN:3,
UI_CANCEL:4,
}

class DwebSession extends SessionObject {
constructor(object_id, service_id, session) {
super(object_id , session, service_id, DwebMessages);
session.track_events(service_id, object_id, this);
}
createDid(name){
return this.call_method("CreateDid", {name: name});
}
getDids(){
return this.call_method("GetDids", {});
}
removeDid(uri){
return this.call_method("RemoveDid", {uri: uri});
}
requestCapabilities(audience,capabilities){
return this.call_method("RequestCapabilities", {audience: audience,capabilities: capabilities});
}
requestSuperuser(){
return this.call_method("RequestSuperuser", {});
}
setUcanUi(provider){
let provider__ = provider;
if (typeof provider === 'function') {
provider = UcanProviderBase.fromFunction(this.service_id, this.session, provider__);
}
return this.call_method("SetUcanUi", {provider: provider});
}
ucansFor(origin){
return this.call_method("UcansFor", {origin: origin});
}
on_event(event) {
// console.log(`DwebSession message: ${event}`);
let decoder = new Decoder(event);
let variant = decoder.enum_tag();
// Event #14: DIDCREATED
if (variant == 14) {
let result = null;
// decoding <no_name>
function DecodeDid(decoder) {
let DidItem = {};
// decoding name
DidItem.name = decoder.string();
// decoding uri
DidItem.uri = decoder.string();
return DidItem;
}
result = DecodeDid(decoder);
this.dispatchEvent(0, result);
}
// Event #15: DIDREMOVED
else if (variant == 15) {
let result = null;
// decoding <no_name>
result = decoder.string();
this.dispatchEvent(1, result);
}
else {
 console.error(`Unable to process variant #${variant}`); }
}
}

DwebSession.prototype.DIDCREATED_EVENT = 0;
DwebSession.prototype.DIDREMOVED_EVENT = 1;
const DwebMessages = {
CreateDidRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(0);
result = result.string(data.name);
return result.value();
}
},
CreateDidResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 0) {
// Success
let result = null;
// decoding <no_name>
function DecodeDid(decoder) {
let DidItem = {};
// decoding name
DidItem.name = decoder.string();
// decoding uri
DidItem.uri = decoder.string();
return DidItem;
}
result = DecodeDid(decoder);
return { success: result }
}
else if (variant == 1) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`CreateDidResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetDidsRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(1);
return result.value();
}
},
GetDidsResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 2) {
// Success
let result = null;
// decoding <no_name>
if (decoder.bool()) {
let count = decoder.u64();
result = [];
for (let i = 0; i < count; i++) {
function DecodeDid(decoder) {
let DidItem = {};
// decoding name
DidItem.name = decoder.string();
// decoding uri
DidItem.uri = decoder.string();
return DidItem;
}
result.push(DecodeDid(decoder));
}
}
return { success: result }
}
else if (variant == 3) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`GetDidsResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
RemoveDidRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(2);
result = result.string(data.uri);
return result.value();
}
},
RemoveDidResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 4) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 5) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`RemoveDidResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
RequestCapabilitiesRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(3);
result = result.string(data.audience);
result = result.u64(data.capabilities.length);
data.capabilities.forEach(data => {
// Capability
function EncodeCapability(CapabilityItem, result) {
result = result.url(CapabilityItem.scope);
result = result.string(CapabilityItem.action);
return result;
}
result = EncodeCapability(data, result);
});
return result.value();
}
},
RequestCapabilitiesResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 6) {
// Success
let result = null;
// decoding <no_name>
result = decoder.string();
return { success: result }
}
else if (variant == 7) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`RequestCapabilitiesResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
RequestSuperuserRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(4);
return result.value();
}
},
RequestSuperuserResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 8) {
// Success
let result = null;
// decoding <no_name>
result = decoder.string();
return { success: result }
}
else if (variant == 9) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`RequestSuperuserResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SetUcanUiRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(5);
result = result.u32(data.provider.id);
return result.value();
}
},
SetUcanUiResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 10) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 11) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`SetUcanUiResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
UcansForRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(6);
result = result.string(data.origin);
return result.value();
}
},
UcansForResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 12) {
// Success
let result = null;
// decoding <no_name>
if (decoder.bool()) {
let count = decoder.u64();
result = [];
for (let i = 0; i < count; i++) {
result.push(new UcanSession(decoder.u32(), service_id, session));}
}
return { success: result }
}
else if (variant == 13) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`UcansForResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
}

class UcanSession extends SessionObject {
constructor(object_id, service_id, session) {
super(object_id , session, service_id, UcanMessages);
}
encoded(){
return this.call_method("Encoded", {});
}
remove(){
return this.call_method("Remove", {});
}
get blocked() {
return this.call_method("GetBlocked");
}
set blocked(value) {
return this.call_method_oneway("SetBlocked", { value });
}
}

const UcanMessages = {
EncodedRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(7);
return result.value();
}
},
EncodedResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 16) {
// Success
let result = null;
// decoding <no_name>
result = decoder.string();
return { success: result }
}
else if (variant == 17) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`EncodedResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
RemoveRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(8);
return result.value();
}
},
RemoveResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 18) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 19) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`RemoveResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetBlockedRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(9);
return result.value();
}
},
GetBlockedResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 20) {
// Success
let result = null;
// decoding <no_name>
result = decoder.bool();
return { success: result }
}
else {
console.error(`GetBlockedResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SetBlockedRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(10);
result = result.bool(data.value);
return result.value();
}
},
}

export class UcanProviderBase extends SessionObject {
constructor(service_id, session) {
super(session.next_id , session, service_id, null);
session.track(this);
}
static fromFunction(service_id, session, fn) {
let obj = new UcanProviderBase(service_id, session);
obj.grantCapabilities = fn.bind(obj);
return obj;
}
on_message(message) {
            // console.log(`Message for UcanProvider ${this.display()}: %o`, message);
let decoder = new Decoder(message.content);
        let variant = decoder.enum_tag();
        // console.log(`Starting at index 21`);
        // console.log(`we got variant ${variant}`);
        // Dispatch based on message.content which is the real payload.
        
switch (variant) {
case 21: {
// console.log(`Extracting parameters for grantCapabilities(...)`);
if (this.grantCapabilities && this.grantCapabilities instanceof Function) {
let result = {};
// decoding capabilities
function DecodeRequestedCapabilities(decoder) {
let RequestedCapabilitiesItem = {};
// decoding url
RequestedCapabilitiesItem.url = decoder.url();
// decoding audience
RequestedCapabilitiesItem.audience = decoder.string();
// decoding capabilities
{
let count = decoder.u64();
RequestedCapabilitiesItem.capabilities = [];
for (let i = 0; i < count; i++) {
function DecodeCapability(decoder) {
let CapabilityItem = {};
// decoding scope
CapabilityItem.scope = decoder.url();
// decoding action
CapabilityItem.action = decoder.string();
return CapabilityItem;
}
RequestedCapabilitiesItem.capabilities.push(DecodeCapability(decoder));
}
} // let count = ... scope
return RequestedCapabilitiesItem;
}
result = DecodeRequestedCapabilities(decoder);
let output = this.grantCapabilities(
result
);
output.then(
success => { // console.log(`UcanProvider.grantCapabilities success: ${success}`);
let encoder = new Encoder();
let result = encoder.enum_tag(11);
// GrantedCapabilities
function EncodeGrantedCapabilities(GrantedCapabilitiesItem, result) {
// Did
function EncodeDid(DidItem, result) {
result = result.string(DidItem.name);
result = result.string(DidItem.uri);
return result;
}
result = EncodeDid(GrantedCapabilitiesItem.issuer, result);
result = result.bool(GrantedCapabilitiesItem.capabilities !== undefined && GrantedCapabilitiesItem.capabilities.length > 0);
if (GrantedCapabilitiesItem.capabilities !== undefined && GrantedCapabilitiesItem.capabilities.length > 0) {
result = result.u64(GrantedCapabilitiesItem.capabilities.length);
GrantedCapabilitiesItem.capabilities.forEach(GrantedCapabilitiesItem => {
// Capability
function EncodeCapability(CapabilityItem, result) {
result = result.url(CapabilityItem.scope);
result = result.string(CapabilityItem.action);
return result;
}
result = EncodeCapability(GrantedCapabilitiesItem, result);
});
 }
result = result.date(GrantedCapabilitiesItem.notBefore);
result = result.date(GrantedCapabilitiesItem.expiration);
return result;
}
result = EncodeGrantedCapabilities(success, result);
message.content = result.value();
this.send_callback_message(message);
},
error => { // console.error(`UcanProvider.grantCapabilities error: ${error}`);
let encoder = new Encoder();
let result = encoder.enum_tag(12);
result = result.void(error);
message.content = result.value();
this.send_callback_message(message);
}
);
}
break; }
default: console.error(`Unexpected variant: ${variant}`);
}
}
}

export const DwebService = {
            get: (session) => {
                return Services.get("DwebService", "96ed74d612578ae5783fe3bb458f6dec4bfc1c4f527d84b481d322d5cb13e4", session).then((service_id) => {
                    session.registerService(service_id, "DwebService");
                    // object_id is always 0 for the service itself.
                    return new DwebSession(0, service_id, session);
                });
            },
        };
