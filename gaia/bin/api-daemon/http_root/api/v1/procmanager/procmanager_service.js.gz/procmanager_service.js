// This file is generated. Do not edit.
              // @generated
              import Services from '../../../../common/client/src/services';
              import SessionObject from '../../../../common/client/src/sessionobject';
              import {Encoder, Decoder} from '../../../../common/client/src/bincode.js';
export const GroupType = {
FOREGROUND:0,
BACKGROUND:1,
TRY_TO_KEEP:2,
}

class ProcessServiceSession extends SessionObject {
constructor(object_id, service_id, session) {
super(object_id , session, service_id, ProcessServiceMessages);
}
abort(){
return this.call_method("Abort", {});
}
add(pid,group){
return this.call_method("Add", {pid: pid,group: group});
}
begin(caller){
return this.call_method("Begin", {caller: caller});
}
commit(){
return this.call_method("Commit", {});
}
hints(){
return this.call_method("Hints", {});
}
modifyHints(hints){
return this.call_method("ModifyHints", {hints: hints});
}
pending(){
return this.call_method("Pending", {});
}
remove(pid){
return this.call_method("Remove", {pid: pid});
}
reset(){
return this.call_method("Reset", {});
}
resetHints(){
return this.call_method("ResetHints", {});
}
}

const ProcessServiceMessages = {
AbortRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(0);
return result.value();
}
},
AbortResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 0) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 1) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`AbortResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
AddRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(1);
result = result.i64(data.pid);
result = result.enum_tag(data.group);
return result.value();
}
},
AddResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 2) {
// Success
let result = null;
// decoding <no_name>
result = decoder.bool();
return { success: result }
}
else if (variant == 3) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`AddResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
BeginRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(2);
result = result.string(data.caller);
return result.value();
}
},
BeginResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 4) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 5) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`BeginResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
CommitRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(3);
return result.value();
}
},
CommitResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 6) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 7) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`CommitResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
HintsRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(4);
return result.value();
}
},
HintsResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 8) {
// Success
let result = null;
// decoding <no_name>
result = decoder.string();
return { success: result }
}
else if (variant == 9) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`HintsResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
ModifyHintsRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(5);
result = result.u64(data.hints.length);
data.hints.forEach(item => {
result = result.string(item);
});
return result.value();
}
},
ModifyHintsResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 10) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 11) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`ModifyHintsResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
PendingRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(6);
return result.value();
}
},
PendingResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 12) {
// Success
let result = null;
// decoding <no_name>
result = decoder.bool();
return { success: result }
}
else if (variant == 13) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`PendingResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
RemoveRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(7);
result = result.i64(data.pid);
return result.value();
}
},
RemoveResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 14) {
// Success
let result = null;
// decoding <no_name>
result = decoder.bool();
return { success: result }
}
else if (variant == 15) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`RemoveResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
ResetRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(8);
return result.value();
}
},
ResetResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 16) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 17) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`ResetResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
ResetHintsRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(9);
return result.value();
}
},
ResetHintsResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 18) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 19) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`ResetHintsResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
}

export const ProcManager = {
            get: (session) => {
                return Services.get("ProcManager", "f3c86da5acc98fd7cee1b3533528aa7dfff89dbe8e357ac26fe53d90e05dd1f7", session).then((service_id) => {
                    session.registerService(service_id, "ProcManager");
                    // object_id is always 0 for the service itself.
                    return new ProcessServiceSession(0, service_id, session);
                });
            },
        };
function wrapBlob(blob) {
            let btype = blob.type;
            return blob.arrayBuffer().then(data => {
                return { __isblob__: true, data: new Uint8Array(data), type: btype }
            });
        }