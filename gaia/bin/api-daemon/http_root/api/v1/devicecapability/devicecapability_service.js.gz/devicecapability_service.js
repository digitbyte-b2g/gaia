// This file is generated. Do not edit.
              // @generated
              import Services from '../../../../common/client/src/services';
              import SessionObject from '../../../../common/client/src/sessionobject';
              import {Encoder, Decoder} from '../../../../common/client/src/bincode.js';
class DeviceCapabilityFactorySession extends SessionObject {
constructor(object_id, service_id, session) {
super(object_id , session, service_id, DeviceCapabilityFactoryMessages);
}
get(feature){
return this.call_method("Get", {feature: feature});
}
}

const DeviceCapabilityFactoryMessages = {
GetRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(0);
result = result.string(data.feature);
return result.value();
}
},
GetResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 0) {
// Success
let result = null;
// decoding <no_name>
result = decoder.json();
return { success: result }
}
else if (variant == 1) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
}

export const DeviceCapabilityManager = {
            get: (session) => {
                return Services.get("DeviceCapabilityManager", "3311871c9c8a4f0b7818744cbefc691e989cb658faa2b7297362f4c16b76510", session).then((service_id) => {
                    session.registerService(service_id, "DeviceCapabilityManager");
                    // object_id is always 0 for the service itself.
                    return new DeviceCapabilityFactorySession(0, service_id, session);
                });
            },
        };
function wrapBlob(blob) {
            let btype = blob.type;
            return blob.arrayBuffer().then(data => {
                return { __isblob__: true, data: new Uint8Array(data), type: btype }
            });
        }