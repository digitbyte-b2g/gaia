// This file is generated. Do not edit.
// @generated
import Services from '../shared/services.js';
import SessionObject from '../shared/sessionobject.js';
import {Encoder, Decoder, wrapBlob} from '../shared/bincode.js';
export const ModificationKind = {
CREATED:0,
MODIFIED:1,
DELETED:2,
CHILD_CREATED:3,
CHILD_MODIFIED:4,
CHILD_DELETED:5,
}

export const ResourceKind = {
LEAF:0,
CONTAINER:1,
}

export const VisitPriority = {
NORMAL:0,
HIGH:1,
VERY_HIGH:2,
}

class ContentStoreSession extends SessionObject {
constructor(object_id, service_id, session) {
super(object_id , session, service_id, ContentStoreMessages);
session.track_events(service_id, object_id, this);
}
addObserver(resource,observer){
let observer__ = observer;
if (typeof observer === 'function') {
observer = ModificationObserverBase.fromFunction(this.service_id, this.session, observer__);
}
return this.call_method("AddObserver", {resource: resource,observer: observer});
}
addTag(id,tag){
return this.call_method("AddTag", {id: id,tag: tag});
}
childByName(parent,name){
return this.call_method("ChildByName", {parent: parent,name: name});
}
childrenOf(id){
return this.call_method("ChildrenOf", {id: id});
}
containerSize(id){
return this.call_method("ContainerSize", {id: id});
}
copyResource(source,target){
return this.call_method("CopyResource", {source: source,target: target});
}
createobj(data,variant,blob){
let promises = [];
if (blob) {
promises.push(wrapBlob(blob));
} else { promises.push(Promise.resolve(blob)); }
return Promise.all(promises).then(results => {
let blob = results[0];
return this.call_method("Createobj", {data: data,variant: variant,blob: blob});
});
}
delete(id){
return this.call_method("Delete", {id: id});
}
deleteVariant(id,variantName){
return this.call_method("DeleteVariant", {id: id,variantName: variantName});
}
getFullPath(id){
return this.call_method("GetFullPath", {id: id});
}
getMetadata(id){
return this.call_method("GetMetadata", {id: id});
}
getRoot(){
return this.call_method("GetRoot", {});
}
getVariant(id,variantName){
return this.call_method("GetVariant", {id: id,variantName: variantName});
}
getVariantJson(id,variantName){
return this.call_method("GetVariantJson", {id: id,variantName: variantName});
}
httpKey(){
return this.call_method("HttpKey", {});
}
importFromPath(parent,path,remove){
return this.call_method("ImportFromPath", {parent: parent,path: path,remove: remove});
}
lastModified(maxCount){
return this.call_method("LastModified", {maxCount: maxCount});
}
removeObserver(resource,observer){
let observer__ = observer;
if (typeof observer === 'function') {
observer = ModificationObserverBase.fromFunction(this.service_id, this.session, observer__);
}
return this.call_method("RemoveObserver", {resource: resource,observer: observer});
}
removeTag(id,tag){
return this.call_method("RemoveTag", {id: id,tag: tag});
}
search(query,maxCount,tag){
return this.call_method("Search", {query: query,maxCount: maxCount,tag: tag});
}
topByFrecency(maxCount){
return this.call_method("TopByFrecency", {maxCount: maxCount});
}
updateVariant(id,variant,blob){
let promises = [];
promises.push(wrapBlob(blob));
return Promise.all(promises).then(results => {
let blob = results[0];
return this.call_method("UpdateVariant", {id: id,variant: variant,blob: blob});
});
}
visit(id,visit){
return this.call_method("Visit", {id: id,visit: visit});
}
visitByName(parent,name,visit){
return this.call_method("VisitByName", {parent: parent,name: name,visit: visit});
}
withUcan(token){
return this.call_method("WithUcan", {token: token});
}
on_event(event) {
// console.log(`ContentStoreSession message: ${event}`);
let decoder = new Decoder(event);
let variant = decoder.enum_tag();
// Event #50: ONRESOURCEMODIFIED
if (variant == 50) {
let result = null;
// decoding <no_name>
function DecodeResourceModification(decoder) {
let ResourceModificationItem = {};
// decoding kind
ResourceModificationItem.kind = decoder.enum_tag();
// decoding id
ResourceModificationItem.id = decoder.string();
// decoding parent
if (decoder.bool()) {
ResourceModificationItem.parent = decoder.string();
}
return ResourceModificationItem;
}
result = DecodeResourceModification(decoder);
this.dispatchEvent(0, result);
}
else {
 console.error(`Unable to process variant #${variant}`); }
}
}

ContentStoreSession.prototype.ONRESOURCEMODIFIED_EVENT = 0;
const ContentStoreMessages = {
AddObserverRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(0);
result = result.string(data.resource);
result = result.u32(data.observer.id);
return result.value();
}
},
AddObserverResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 0) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 1) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`AddObserverResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
AddTagRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(1);
result = result.string(data.id);
result = result.string(data.tag);
return result.value();
}
},
AddTagResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 2) {
// Success
let result = null;
// decoding <no_name>
function DecodeMetadata(decoder) {
let MetadataItem = {};
// decoding id
MetadataItem.id = decoder.string();
// decoding parent
MetadataItem.parent = decoder.string();
// decoding name
MetadataItem.name = decoder.string();
// decoding kind
MetadataItem.kind = decoder.enum_tag();
// decoding created
MetadataItem.created = decoder.date();
// decoding modified
MetadataItem.modified = decoder.date();
// decoding tags
{
let count = decoder.u64();
MetadataItem.tags = [];
for (let i = 0; i < count; i++) {
MetadataItem.tags.push(decoder.string());
}
} // let count = ... scope
// decoding variants
{
let count = decoder.u64();
MetadataItem.variants = [];
for (let i = 0; i < count; i++) {
function DecodeVariant(decoder) {
let VariantItem = {};
// decoding name
VariantItem.name = decoder.string();
// decoding mimeType
VariantItem.mimeType = decoder.string();
// decoding size
VariantItem.size = decoder.i64();
return VariantItem;
}
MetadataItem.variants.push(DecodeVariant(decoder));
}
} // let count = ... scope
return MetadataItem;
}
result = DecodeMetadata(decoder);
return { success: result }
}
else if (variant == 3) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`AddTagResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
ChildByNameRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(2);
result = result.string(data.parent);
result = result.string(data.name);
return result.value();
}
},
ChildByNameResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 4) {
// Success
let result = null;
// decoding <no_name>
function DecodeMetadata(decoder) {
let MetadataItem = {};
// decoding id
MetadataItem.id = decoder.string();
// decoding parent
MetadataItem.parent = decoder.string();
// decoding name
MetadataItem.name = decoder.string();
// decoding kind
MetadataItem.kind = decoder.enum_tag();
// decoding created
MetadataItem.created = decoder.date();
// decoding modified
MetadataItem.modified = decoder.date();
// decoding tags
{
let count = decoder.u64();
MetadataItem.tags = [];
for (let i = 0; i < count; i++) {
MetadataItem.tags.push(decoder.string());
}
} // let count = ... scope
// decoding variants
{
let count = decoder.u64();
MetadataItem.variants = [];
for (let i = 0; i < count; i++) {
function DecodeVariant(decoder) {
let VariantItem = {};
// decoding name
VariantItem.name = decoder.string();
// decoding mimeType
VariantItem.mimeType = decoder.string();
// decoding size
VariantItem.size = decoder.i64();
return VariantItem;
}
MetadataItem.variants.push(DecodeVariant(decoder));
}
} // let count = ... scope
return MetadataItem;
}
result = DecodeMetadata(decoder);
return { success: result }
}
else if (variant == 5) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`ChildByNameResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
ChildrenOfRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(3);
result = result.string(data.id);
return result.value();
}
},
ChildrenOfResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 6) {
// Success
let result = null;
// decoding <no_name>
result = new MetadataCursorSession(decoder.u32(), service_id, session);return { success: result }
}
else if (variant == 7) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`ChildrenOfResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
ContainerSizeRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(4);
result = result.string(data.id);
return result.value();
}
},
ContainerSizeResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 8) {
// Success
let result = null;
// decoding <no_name>
result = decoder.i64();
return { success: result }
}
else if (variant == 9) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`ContainerSizeResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
CopyResourceRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(5);
result = result.string(data.source);
result = result.string(data.target);
return result.value();
}
},
CopyResourceResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 10) {
// Success
let result = null;
// decoding <no_name>
function DecodeMetadata(decoder) {
let MetadataItem = {};
// decoding id
MetadataItem.id = decoder.string();
// decoding parent
MetadataItem.parent = decoder.string();
// decoding name
MetadataItem.name = decoder.string();
// decoding kind
MetadataItem.kind = decoder.enum_tag();
// decoding created
MetadataItem.created = decoder.date();
// decoding modified
MetadataItem.modified = decoder.date();
// decoding tags
{
let count = decoder.u64();
MetadataItem.tags = [];
for (let i = 0; i < count; i++) {
MetadataItem.tags.push(decoder.string());
}
} // let count = ... scope
// decoding variants
{
let count = decoder.u64();
MetadataItem.variants = [];
for (let i = 0; i < count; i++) {
function DecodeVariant(decoder) {
let VariantItem = {};
// decoding name
VariantItem.name = decoder.string();
// decoding mimeType
VariantItem.mimeType = decoder.string();
// decoding size
VariantItem.size = decoder.i64();
return VariantItem;
}
MetadataItem.variants.push(DecodeVariant(decoder));
}
} // let count = ... scope
return MetadataItem;
}
result = DecodeMetadata(decoder);
return { success: result }
}
else if (variant == 11) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`CopyResourceResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
CreateobjRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(6);
// CreationData
function EncodeCreationData(CreationDataItem, result) {
result = result.string(CreationDataItem.parent);
result = result.string(CreationDataItem.name);
result = result.enum_tag(CreationDataItem.kind);
result = result.u64(CreationDataItem.tags.length);
CreationDataItem.tags.forEach(item => {
result = result.string(item);
});
return result;
}
result = EncodeCreationData(data.data, result);
result = result.string(data.variant);
result = result.bool(data.blob !== undefined);
if (data.blob !== undefined) {
result = result.blob(data.blob);
}
return result.value();
}
},
CreateobjResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 12) {
// Success
let result = null;
// decoding <no_name>
function DecodeMetadata(decoder) {
let MetadataItem = {};
// decoding id
MetadataItem.id = decoder.string();
// decoding parent
MetadataItem.parent = decoder.string();
// decoding name
MetadataItem.name = decoder.string();
// decoding kind
MetadataItem.kind = decoder.enum_tag();
// decoding created
MetadataItem.created = decoder.date();
// decoding modified
MetadataItem.modified = decoder.date();
// decoding tags
{
let count = decoder.u64();
MetadataItem.tags = [];
for (let i = 0; i < count; i++) {
MetadataItem.tags.push(decoder.string());
}
} // let count = ... scope
// decoding variants
{
let count = decoder.u64();
MetadataItem.variants = [];
for (let i = 0; i < count; i++) {
function DecodeVariant(decoder) {
let VariantItem = {};
// decoding name
VariantItem.name = decoder.string();
// decoding mimeType
VariantItem.mimeType = decoder.string();
// decoding size
VariantItem.size = decoder.i64();
return VariantItem;
}
MetadataItem.variants.push(DecodeVariant(decoder));
}
} // let count = ... scope
return MetadataItem;
}
result = DecodeMetadata(decoder);
return { success: result }
}
else if (variant == 13) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`CreateobjResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
DeleteRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(7);
result = result.string(data.id);
return result.value();
}
},
DeleteResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 14) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 15) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`DeleteResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
DeleteVariantRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(8);
result = result.string(data.id);
result = result.string(data.variantName);
return result.value();
}
},
DeleteVariantResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 16) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 17) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`DeleteVariantResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetFullPathRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(9);
result = result.string(data.id);
return result.value();
}
},
GetFullPathResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 18) {
// Success
let result = null;
// decoding <no_name>
{
let count = decoder.u64();
result = [];
for (let i = 0; i < count; i++) {
function DecodeMetadata(decoder) {
let MetadataItem = {};
// decoding id
MetadataItem.id = decoder.string();
// decoding parent
MetadataItem.parent = decoder.string();
// decoding name
MetadataItem.name = decoder.string();
// decoding kind
MetadataItem.kind = decoder.enum_tag();
// decoding created
MetadataItem.created = decoder.date();
// decoding modified
MetadataItem.modified = decoder.date();
// decoding tags
{
let count = decoder.u64();
MetadataItem.tags = [];
for (let i = 0; i < count; i++) {
MetadataItem.tags.push(decoder.string());
}
} // let count = ... scope
// decoding variants
{
let count = decoder.u64();
MetadataItem.variants = [];
for (let i = 0; i < count; i++) {
function DecodeVariant(decoder) {
let VariantItem = {};
// decoding name
VariantItem.name = decoder.string();
// decoding mimeType
VariantItem.mimeType = decoder.string();
// decoding size
VariantItem.size = decoder.i64();
return VariantItem;
}
MetadataItem.variants.push(DecodeVariant(decoder));
}
} // let count = ... scope
return MetadataItem;
}
result.push(DecodeMetadata(decoder));
}
} // let count = ... scope
return { success: result }
}
else if (variant == 19) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetFullPathResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetMetadataRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(10);
result = result.string(data.id);
return result.value();
}
},
GetMetadataResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 20) {
// Success
let result = null;
// decoding <no_name>
function DecodeMetadata(decoder) {
let MetadataItem = {};
// decoding id
MetadataItem.id = decoder.string();
// decoding parent
MetadataItem.parent = decoder.string();
// decoding name
MetadataItem.name = decoder.string();
// decoding kind
MetadataItem.kind = decoder.enum_tag();
// decoding created
MetadataItem.created = decoder.date();
// decoding modified
MetadataItem.modified = decoder.date();
// decoding tags
{
let count = decoder.u64();
MetadataItem.tags = [];
for (let i = 0; i < count; i++) {
MetadataItem.tags.push(decoder.string());
}
} // let count = ... scope
// decoding variants
{
let count = decoder.u64();
MetadataItem.variants = [];
for (let i = 0; i < count; i++) {
function DecodeVariant(decoder) {
let VariantItem = {};
// decoding name
VariantItem.name = decoder.string();
// decoding mimeType
VariantItem.mimeType = decoder.string();
// decoding size
VariantItem.size = decoder.i64();
return VariantItem;
}
MetadataItem.variants.push(DecodeVariant(decoder));
}
} // let count = ... scope
return MetadataItem;
}
result = DecodeMetadata(decoder);
return { success: result }
}
else if (variant == 21) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetMetadataResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetRootRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(11);
return result.value();
}
},
GetRootResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 22) {
// Success
let result = null;
// decoding <no_name>
function DecodeMetadata(decoder) {
let MetadataItem = {};
// decoding id
MetadataItem.id = decoder.string();
// decoding parent
MetadataItem.parent = decoder.string();
// decoding name
MetadataItem.name = decoder.string();
// decoding kind
MetadataItem.kind = decoder.enum_tag();
// decoding created
MetadataItem.created = decoder.date();
// decoding modified
MetadataItem.modified = decoder.date();
// decoding tags
{
let count = decoder.u64();
MetadataItem.tags = [];
for (let i = 0; i < count; i++) {
MetadataItem.tags.push(decoder.string());
}
} // let count = ... scope
// decoding variants
{
let count = decoder.u64();
MetadataItem.variants = [];
for (let i = 0; i < count; i++) {
function DecodeVariant(decoder) {
let VariantItem = {};
// decoding name
VariantItem.name = decoder.string();
// decoding mimeType
VariantItem.mimeType = decoder.string();
// decoding size
VariantItem.size = decoder.i64();
return VariantItem;
}
MetadataItem.variants.push(DecodeVariant(decoder));
}
} // let count = ... scope
return MetadataItem;
}
result = DecodeMetadata(decoder);
return { success: result }
}
else if (variant == 23) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetRootResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetVariantRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(12);
result = result.string(data.id);
result = result.bool(data.variantName !== undefined);
if (data.variantName !== undefined) {
result = result.string(data.variantName);
}
return result.value();
}
},
GetVariantResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 24) {
// Success
let result = null;
// decoding <no_name>
result = decoder.blob();
return { success: result }
}
else if (variant == 25) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetVariantResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetVariantJsonRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(13);
result = result.string(data.id);
result = result.bool(data.variantName !== undefined);
if (data.variantName !== undefined) {
result = result.string(data.variantName);
}
return result.value();
}
},
GetVariantJsonResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 26) {
// Success
let result = null;
// decoding <no_name>
result = decoder.json();
return { success: result }
}
else if (variant == 27) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetVariantJsonResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
HttpKeyRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(14);
return result.value();
}
},
HttpKeyResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 28) {
// Success
let result = null;
// decoding <no_name>
result = decoder.string();
return { success: result }
}
else if (variant == 29) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`HttpKeyResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
ImportFromPathRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(15);
result = result.string(data.parent);
result = result.string(data.path);
result = result.bool(data.remove);
return result.value();
}
},
ImportFromPathResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 30) {
// Success
let result = null;
// decoding <no_name>
function DecodeMetadata(decoder) {
let MetadataItem = {};
// decoding id
MetadataItem.id = decoder.string();
// decoding parent
MetadataItem.parent = decoder.string();
// decoding name
MetadataItem.name = decoder.string();
// decoding kind
MetadataItem.kind = decoder.enum_tag();
// decoding created
MetadataItem.created = decoder.date();
// decoding modified
MetadataItem.modified = decoder.date();
// decoding tags
{
let count = decoder.u64();
MetadataItem.tags = [];
for (let i = 0; i < count; i++) {
MetadataItem.tags.push(decoder.string());
}
} // let count = ... scope
// decoding variants
{
let count = decoder.u64();
MetadataItem.variants = [];
for (let i = 0; i < count; i++) {
function DecodeVariant(decoder) {
let VariantItem = {};
// decoding name
VariantItem.name = decoder.string();
// decoding mimeType
VariantItem.mimeType = decoder.string();
// decoding size
VariantItem.size = decoder.i64();
return VariantItem;
}
MetadataItem.variants.push(DecodeVariant(decoder));
}
} // let count = ... scope
return MetadataItem;
}
result = DecodeMetadata(decoder);
return { success: result }
}
else if (variant == 31) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`ImportFromPathResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
LastModifiedRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(16);
result = result.i64(data.maxCount);
return result.value();
}
},
LastModifiedResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 32) {
// Success
let result = null;
// decoding <no_name>
result = new MetadataCursorSession(decoder.u32(), service_id, session);return { success: result }
}
else if (variant == 33) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`LastModifiedResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
RemoveObserverRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(17);
result = result.string(data.resource);
result = result.u32(data.observer.id);
return result.value();
}
},
RemoveObserverResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 34) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 35) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`RemoveObserverResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
RemoveTagRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(18);
result = result.string(data.id);
result = result.string(data.tag);
return result.value();
}
},
RemoveTagResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 36) {
// Success
let result = null;
// decoding <no_name>
function DecodeMetadata(decoder) {
let MetadataItem = {};
// decoding id
MetadataItem.id = decoder.string();
// decoding parent
MetadataItem.parent = decoder.string();
// decoding name
MetadataItem.name = decoder.string();
// decoding kind
MetadataItem.kind = decoder.enum_tag();
// decoding created
MetadataItem.created = decoder.date();
// decoding modified
MetadataItem.modified = decoder.date();
// decoding tags
{
let count = decoder.u64();
MetadataItem.tags = [];
for (let i = 0; i < count; i++) {
MetadataItem.tags.push(decoder.string());
}
} // let count = ... scope
// decoding variants
{
let count = decoder.u64();
MetadataItem.variants = [];
for (let i = 0; i < count; i++) {
function DecodeVariant(decoder) {
let VariantItem = {};
// decoding name
VariantItem.name = decoder.string();
// decoding mimeType
VariantItem.mimeType = decoder.string();
// decoding size
VariantItem.size = decoder.i64();
return VariantItem;
}
MetadataItem.variants.push(DecodeVariant(decoder));
}
} // let count = ... scope
return MetadataItem;
}
result = DecodeMetadata(decoder);
return { success: result }
}
else if (variant == 37) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`RemoveTagResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SearchRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(19);
result = result.string(data.query);
result = result.i64(data.maxCount);
result = result.bool(data.tag !== undefined);
if (data.tag !== undefined) {
result = result.string(data.tag);
}
return result.value();
}
},
SearchResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 38) {
// Success
let result = null;
// decoding <no_name>
result = new MetadataCursorSession(decoder.u32(), service_id, session);return { success: result }
}
else if (variant == 39) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`SearchResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
TopByFrecencyRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(20);
result = result.i64(data.maxCount);
return result.value();
}
},
TopByFrecencyResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 40) {
// Success
let result = null;
// decoding <no_name>
result = new MetadataCursorSession(decoder.u32(), service_id, session);return { success: result }
}
else if (variant == 41) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`TopByFrecencyResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
UpdateVariantRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(21);
result = result.string(data.id);
result = result.string(data.variant);
result = result.blob(data.blob);
return result.value();
}
},
UpdateVariantResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 42) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 43) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`UpdateVariantResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
VisitRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(22);
result = result.string(data.id);
result = result.enum_tag(data.visit);
return result.value();
}
},
VisitResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 44) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 45) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`VisitResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
VisitByNameRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(23);
result = result.string(data.parent);
result = result.string(data.name);
result = result.enum_tag(data.visit);
return result.value();
}
},
VisitByNameResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 46) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 47) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`VisitByNameResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
WithUcanRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(24);
result = result.string(data.token);
return result.value();
}
},
WithUcanResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 48) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 49) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`WithUcanResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
}

class MetadataCursorSession extends SessionObject {
constructor(object_id, service_id, session) {
super(object_id , session, service_id, MetadataCursorMessages);
}
next(){
return this.call_method("Next", {});
}
}

const MetadataCursorMessages = {
NextRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(25);
return result.value();
}
},
NextResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 51) {
// Success
let result = null;
// decoding <no_name>
{
let count = decoder.u64();
result = [];
for (let i = 0; i < count; i++) {
function DecodeMetadata(decoder) {
let MetadataItem = {};
// decoding id
MetadataItem.id = decoder.string();
// decoding parent
MetadataItem.parent = decoder.string();
// decoding name
MetadataItem.name = decoder.string();
// decoding kind
MetadataItem.kind = decoder.enum_tag();
// decoding created
MetadataItem.created = decoder.date();
// decoding modified
MetadataItem.modified = decoder.date();
// decoding tags
{
let count = decoder.u64();
MetadataItem.tags = [];
for (let i = 0; i < count; i++) {
MetadataItem.tags.push(decoder.string());
}
} // let count = ... scope
// decoding variants
{
let count = decoder.u64();
MetadataItem.variants = [];
for (let i = 0; i < count; i++) {
function DecodeVariant(decoder) {
let VariantItem = {};
// decoding name
VariantItem.name = decoder.string();
// decoding mimeType
VariantItem.mimeType = decoder.string();
// decoding size
VariantItem.size = decoder.i64();
return VariantItem;
}
MetadataItem.variants.push(DecodeVariant(decoder));
}
} // let count = ... scope
return MetadataItem;
}
result.push(DecodeMetadata(decoder));
}
} // let count = ... scope
return { success: result }
}
else if (variant == 52) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`NextResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
}

export class ModificationObserverBase extends SessionObject {
constructor(service_id, session) {
super(session.next_id , session, service_id, null);
session.track(this);
}
static fromFunction(service_id, session, fn) {
let obj = new ModificationObserverBase(service_id, session);
obj.modified = fn.bind(obj);
return obj;
}
on_message(message) {
            // console.log(`Message for ModificationObserver ${this.display()}: %o`, message);
let decoder = new Decoder(message.content);
        let variant = decoder.enum_tag();
        // console.log(`Starting at index 53`);
        // console.log(`we got variant ${variant}`);
        // Dispatch based on message.content which is the real payload.
        
switch (variant) {
case 53: {
// console.log(`Extracting parameters for modified(...)`);
if (this.modified && this.modified instanceof Function) {
let result = {};
// decoding modifications
function DecodeResourceModification(decoder) {
let ResourceModificationItem = {};
// decoding kind
ResourceModificationItem.kind = decoder.enum_tag();
// decoding id
ResourceModificationItem.id = decoder.string();
// decoding parent
if (decoder.bool()) {
ResourceModificationItem.parent = decoder.string();
}
return ResourceModificationItem;
}
result = DecodeResourceModification(decoder);
let output = this.modified(
result
);
output.then(
success => { // console.log(`ModificationObserver.modified success: ${success}`);
let encoder = new Encoder();
let result = encoder.enum_tag(26);
result = result.void(success);
message.content = result.value();
this.send_callback_message(message);
},
error => { // console.error(`ModificationObserver.modified error: ${error}`);
let encoder = new Encoder();
let result = encoder.enum_tag(27);
result = result.void(error);
message.content = result.value();
this.send_callback_message(message);
}
);
}
break; }
default: console.error(`Unexpected variant: ${variant}`);
}
}
}

export const ContentManager = {
            get: (session) => {
                return Services.get("ContentManager", "9e326c32d346a3b3ba24eff2f1355e19b8c74f1f2990d0d0280c1fc2a1a9c", session).then((service_id) => {
                    session.registerService(service_id, "ContentManager");
                    // object_id is always 0 for the service itself.
                    return new ContentStoreSession(0, service_id, session);
                });
            },
        };
