// This file is generated. Do not edit.
              // @generated
              import Services from '../../../../common/client/src/services';
              import SessionObject from '../../../../common/client/src/sessionobject';
              import {Encoder, Decoder} from '../../../../common/client/src/bincode.js';
export const AudioVolumeState = {
NONE:0,
VOLUME_UP:1,
VOLUME_DOWN:2,
VOLUME_SHOW:3,
}

class AudioVolumeSession extends SessionObject {
constructor(object_id, service_id, session) {
super(object_id , session, service_id, AudioVolumeMessages);
session.track_events(service_id, object_id, this);
}
requestVolumeDown(){
return this.call_method("RequestVolumeDown", {});
}
requestVolumeShow(){
return this.call_method("RequestVolumeShow", {});
}
requestVolumeUp(){
return this.call_method("RequestVolumeUp", {});
}
on_event(event) {
// console.log(`AudioVolumeSession message: ${event}`);
let decoder = new Decoder(event);
let variant = decoder.enum_tag();
// Event #6: AUDIO_VOLUME_CHANGED
if (variant == 6) {
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
this.dispatchEvent(0, result);
}
else {
 console.error(`Unable to process variant #${variant}`); }
}
}

AudioVolumeSession.prototype.AUDIO_VOLUME_CHANGED_EVENT = 0;
const AudioVolumeMessages = {
RequestVolumeDownRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(0);
return result.value();
}
},
RequestVolumeDownResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 0) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 1) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`RequestVolumeDownResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
RequestVolumeShowRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(1);
return result.value();
}
},
RequestVolumeShowResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 2) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 3) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`RequestVolumeShowResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
RequestVolumeUpRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(2);
return result.value();
}
},
RequestVolumeUpResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 4) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 5) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`RequestVolumeUpResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
}

export const AudioVolumeManager = {
            get: (session) => {
                return Services.get("AudioVolumeManager", "9d4165739daf874efe701278f273e22aeebee8013e38f6772df4912bf90", session).then((service_id) => {
                    session.registerService(service_id, "AudioVolumeManager");
                    // object_id is always 0 for the service itself.
                    return new AudioVolumeSession(0, service_id, session);
                });
            },
        };
function wrapBlob(blob) {
            let btype = blob.type;
            return blob.arrayBuffer().then(data => {
                return { __isblob__: true, data: new Uint8Array(data), type: btype }
            });
        }