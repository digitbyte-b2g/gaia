// This file is generated. Do not edit.
// @generated
import Services from '../shared/services.js';
import SessionObject from '../shared/sessionobject.js';
import {Encoder, Decoder, wrapBlob} from '../shared/bincode.js';
export const GetErrorReason = {
UNKNOWN_ERROR:0,
NON_EXISTING_SETTING:1,
}

class SettingsFactorySession extends SessionObject {
constructor(object_id, service_id, session) {
super(object_id , session, service_id, SettingsFactoryMessages);
session.track_events(service_id, object_id, this);
}
addObserver(name,observer){
let observer__ = observer;
if (typeof observer === 'function') {
observer = SettingObserverBase.fromFunction(this.service_id, this.session, observer__);
}
return this.call_method("AddObserver", {name: name,observer: observer});
}
clear(){
return this.call_method("Clear", {});
}
get(name){
return this.call_method("Get", {name: name});
}
getBatch(name){
return this.call_method("GetBatch", {name: name});
}
removeObserver(name,observer){
let observer__ = observer;
if (typeof observer === 'function') {
observer = SettingObserverBase.fromFunction(this.service_id, this.session, observer__);
}
return this.call_method("RemoveObserver", {name: name,observer: observer});
}
set(settings){
return this.call_method("Set", {settings: settings});
}
on_event(event) {
// console.log(`SettingsFactorySession message: ${event}`);
let decoder = new Decoder(event);
let variant = decoder.enum_tag();
// Event #12: CHANGE
if (variant == 12) {
let result = null;
// decoding <no_name>
function DecodeSettingInfo(decoder) {
let SettingInfoItem = {};
// decoding name
SettingInfoItem.name = decoder.string();
// decoding value
SettingInfoItem.value = decoder.json();
return SettingInfoItem;
}
result = DecodeSettingInfo(decoder);
this.dispatchEvent(0, result);
}
else {
 console.error(`Unable to process variant #${variant}`); }
}
}

SettingsFactorySession.prototype.CHANGE_EVENT = 0;
const SettingsFactoryMessages = {
AddObserverRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(0);
result = result.string(data.name);
result = result.u32(data.observer.id);
return result.value();
}
},
AddObserverResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 0) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 1) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`AddObserverResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
ClearRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(1);
return result.value();
}
},
ClearResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 2) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 3) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`ClearResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(2);
result = result.string(data.name);
return result.value();
}
},
GetResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 4) {
// Success
let result = null;
// decoding <no_name>
function DecodeSettingInfo(decoder) {
let SettingInfoItem = {};
// decoding name
SettingInfoItem.name = decoder.string();
// decoding value
SettingInfoItem.value = decoder.json();
return SettingInfoItem;
}
result = DecodeSettingInfo(decoder);
return { success: result }
}
else if (variant == 5) {
// Error
let result = null;
// decoding <no_name>
function DecodeGetError(decoder) {
let GetErrorItem = {};
// decoding name
GetErrorItem.name = decoder.string();
// decoding reason
GetErrorItem.reason = decoder.enum_tag();
return GetErrorItem;
}
result = DecodeGetError(decoder);
return { error: result }
}
else {
console.error(`GetResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetBatchRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(3);
result = result.u64(data.name.length);
data.name.forEach(item => {
result = result.string(item);
});
return result.value();
}
},
GetBatchResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 6) {
// Success
let result = null;
// decoding <no_name>
{
let count = decoder.u64();
result = [];
for (let i = 0; i < count; i++) {
function DecodeSettingInfo(decoder) {
let SettingInfoItem = {};
// decoding name
SettingInfoItem.name = decoder.string();
// decoding value
SettingInfoItem.value = decoder.json();
return SettingInfoItem;
}
result.push(DecodeSettingInfo(decoder));
}
} // let count = ... scope
return { success: result }
}
else if (variant == 7) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetBatchResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
RemoveObserverRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(4);
result = result.string(data.name);
result = result.u32(data.observer.id);
return result.value();
}
},
RemoveObserverResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 8) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 9) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`RemoveObserverResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SetRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(5);
result = result.u64(data.settings.length);
data.settings.forEach(data => {
// SettingInfo
function EncodeSettingInfo(SettingInfoItem, result) {
result = result.string(SettingInfoItem.name);
result = result.json(SettingInfoItem.value);
return result;
}
result = EncodeSettingInfo(data, result);
});
return result.value();
}
},
SetResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 10) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 11) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`SetResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
}

export class SettingObserverBase extends SessionObject {
constructor(service_id, session) {
super(session.next_id , session, service_id, null);
session.track(this);
}
static fromFunction(service_id, session, fn) {
let obj = new SettingObserverBase(service_id, session);
obj.callback = fn.bind(obj);
return obj;
}
on_message(message) {
            // console.log(`Message for SettingObserver ${this.display()}: %o`, message);
let decoder = new Decoder(message.content);
        let variant = decoder.enum_tag();
        // console.log(`Starting at index 13`);
        // console.log(`we got variant ${variant}`);
        // Dispatch based on message.content which is the real payload.
        
switch (variant) {
case 13: {
// console.log(`Extracting parameters for callback(...)`);
if (this.callback && this.callback instanceof Function) {
let result = {};
// decoding setting
function DecodeSettingInfo(decoder) {
let SettingInfoItem = {};
// decoding name
SettingInfoItem.name = decoder.string();
// decoding value
SettingInfoItem.value = decoder.json();
return SettingInfoItem;
}
result = DecodeSettingInfo(decoder);
let output = this.callback(
result
);
output.then(
success => { // console.log(`SettingObserver.callback success: ${success}`);
let encoder = new Encoder();
let result = encoder.enum_tag(6);
result = result.void(success);
message.content = result.value();
this.send_callback_message(message);
},
error => { // console.error(`SettingObserver.callback error: ${error}`);
let encoder = new Encoder();
let result = encoder.enum_tag(7);
result = result.void(error);
message.content = result.value();
this.send_callback_message(message);
}
);
}
break; }
default: console.error(`Unexpected variant: ${variant}`);
}
}
}

export const SettingsManager = {
            get: (session) => {
                return Services.get("SettingsManager", "d2e7699bc8cdc73421e28699cfb91dc2b149c8a64823efc2416f1382826dc0", session).then((service_id) => {
                    session.registerService(service_id, "SettingsManager");
                    // object_id is always 0 for the service itself.
                    return new SettingsFactorySession(0, service_id, session);
                });
            },
        };
