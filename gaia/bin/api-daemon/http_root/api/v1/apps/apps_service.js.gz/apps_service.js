// This file is generated. Do not edit.
              // @generated
              import Services from '../../../../common/client/src/services';
              import SessionObject from '../../../../common/client/src/sessionobject';
              import {Encoder, Decoder} from '../../../../common/client/src/bincode.js';
export const AppsInstallState = {
INSTALLED:0,
INSTALLING:1,
PENDING:2,
}

export const AppsServiceError = {
APP_NOT_FOUND:0,
CANCELED:1,
CLEAR_DATA_ERROR:2,
DEPENDENCIES_ERROR:3,
DISK_SPACE_NOT_ENOUGH:4,
DOWNLOAD_MANIFEST_FAILED:5,
DOWNLOAD_PACKAGE_FAILED:6,
DUPLICATED_ACTION:7,
INVALID_APP_NAME:8,
INVALID_DEEPLINKS:9,
INVALID_ICON:10,
INVALID_START_URL:11,
INVALID_STATE:12,
INVALID_MANIFEST:13,
INVALID_ORIGIN:14,
INVALID_PACKAGE:15,
INVALID_SCOPE:16,
INVALID_SIGNATURE:17,
INVALID_UPDATE_URL:18,
INVALID_CERTIFICATE:19,
NETWORK_FAILURE:20,
FILESYSTEM_FAILURE:21,
PACKAGE_CORRUPT:22,
REGISTRATION_ERROR:23,
REINSTALL_FORBIDDEN:24,
UPDATE_ERROR:25,
UNINSTALL_FORBIDDEN:26,
UNINSTALL_ERROR:27,
UNKNOWN_ERROR:28,
}

export const AppsServiceState = {
INITIALIZING:0,
RUNNING:1,
TERMINATING:2,
}

export const AppsStatus = {
ENABLED:0,
DISABLED:1,
}

export const AppsUpdateState = {
IDLE:0,
AVAILABLE:1,
DOWNLOADING:2,
UPDATING:3,
PENDING:4,
}

export const ClearType = {
BROWSER:0,
STORAGE:1,
}

export const ConnectionType = {
WI_FI_ONLY:0,
ANY:1,
}

export const TokenType = {
ACCOUNT:0,
RESTRICTED:1,
}

class AppsEngineSession extends SessionObject {
constructor(object_id, service_id, session) {
super(object_id , session, service_id, AppsEngineMessages);
session.track_events(service_id, object_id, this);
}
cancelDownload(updateUrl){
return this.call_method("CancelDownload", {updateUrl: updateUrl});
}
checkForUpdate(updateUrl,appsOption){
return this.call_method("CheckForUpdate", {updateUrl: updateUrl,appsOption: appsOption});
}
clear(manifestUrl,dataType){
return this.call_method("Clear", {manifestUrl: manifestUrl,dataType: dataType});
}
getAll(){
return this.call_method("GetAll", {});
}
getApp(manifestUrl){
return this.call_method("GetApp", {manifestUrl: manifestUrl});
}
getState(){
return this.call_method("GetState", {});
}
getUpdatePolicy(){
return this.call_method("GetUpdatePolicy", {});
}
installPackage(updateUrl){
return this.call_method("InstallPackage", {updateUrl: updateUrl});
}
installPwa(manifestUrl){
return this.call_method("InstallPwa", {manifestUrl: manifestUrl});
}
setEnabled(manifestUrl,status){
return this.call_method("SetEnabled", {manifestUrl: manifestUrl,status: status});
}
setTokenProvider(provider){
let provider__ = provider;
if (typeof provider === 'function') {
provider = TokenProviderBase.fromFunction(this.service_id, this.session, provider__);
}
return this.call_method("SetTokenProvider", {provider: provider});
}
setUpdatePolicy(config){
return this.call_method("SetUpdatePolicy", {config: config});
}
uninstall(manifestUrl){
return this.call_method("Uninstall", {manifestUrl: manifestUrl});
}
update(manifestUrl,appsOption){
return this.call_method("Update", {manifestUrl: manifestUrl,appsOption: appsOption});
}
verify(manifestUrl,certType,folderName){
return this.call_method("Verify", {manifestUrl: manifestUrl,certType: certType,folderName: folderName});
}
on_event(event) {
// console.log(`AppsEngineSession message: ${event}`);
let decoder = new Decoder(event);
let variant = decoder.enum_tag();
// Event #30: APP_DOWNLOAD_FAILED
if (variant == 30) {
let result = null;
// decoding <no_name>
function DecodeDownloadFailedReason(decoder) {
let DownloadFailedReasonItem = {};
// decoding appsObject
function DecodeAppsObject(decoder) {
let AppsObjectItem = {};
// decoding name
AppsObjectItem.name = decoder.string();
// decoding installState
AppsObjectItem.installState = decoder.enum_tag();
// decoding manifestUrl
AppsObjectItem.manifestUrl = decoder.url();
// decoding removable
AppsObjectItem.removable = decoder.bool();
// decoding status
AppsObjectItem.status = decoder.enum_tag();
// decoding updateManifestUrl
if (decoder.bool()) {
AppsObjectItem.updateManifestUrl = decoder.url();
}
// decoding updateState
AppsObjectItem.updateState = decoder.enum_tag();
// decoding updateUrl
if (decoder.bool()) {
AppsObjectItem.updateUrl = decoder.url();
}
// decoding allowedAutoDownload
AppsObjectItem.allowedAutoDownload = decoder.bool();
// decoding preloaded
AppsObjectItem.preloaded = decoder.bool();
// decoding progress
AppsObjectItem.progress = decoder.i64();
// decoding origin
AppsObjectItem.origin = decoder.string();
return AppsObjectItem;
}
DownloadFailedReasonItem.appsObject = DecodeAppsObject(decoder);
// decoding reason
DownloadFailedReasonItem.reason = decoder.enum_tag();
return DownloadFailedReasonItem;
}
result = DecodeDownloadFailedReason(decoder);
this.dispatchEvent(0, result);
}
// Event #31: APP_INSTALLED
else if (variant == 31) {
let result = null;
// decoding <no_name>
function DecodeAppsObject(decoder) {
let AppsObjectItem = {};
// decoding name
AppsObjectItem.name = decoder.string();
// decoding installState
AppsObjectItem.installState = decoder.enum_tag();
// decoding manifestUrl
AppsObjectItem.manifestUrl = decoder.url();
// decoding removable
AppsObjectItem.removable = decoder.bool();
// decoding status
AppsObjectItem.status = decoder.enum_tag();
// decoding updateManifestUrl
if (decoder.bool()) {
AppsObjectItem.updateManifestUrl = decoder.url();
}
// decoding updateState
AppsObjectItem.updateState = decoder.enum_tag();
// decoding updateUrl
if (decoder.bool()) {
AppsObjectItem.updateUrl = decoder.url();
}
// decoding allowedAutoDownload
AppsObjectItem.allowedAutoDownload = decoder.bool();
// decoding preloaded
AppsObjectItem.preloaded = decoder.bool();
// decoding progress
AppsObjectItem.progress = decoder.i64();
// decoding origin
AppsObjectItem.origin = decoder.string();
return AppsObjectItem;
}
result = DecodeAppsObject(decoder);
this.dispatchEvent(1, result);
}
// Event #32: APP_INSTALLING
else if (variant == 32) {
let result = null;
// decoding <no_name>
function DecodeAppsObject(decoder) {
let AppsObjectItem = {};
// decoding name
AppsObjectItem.name = decoder.string();
// decoding installState
AppsObjectItem.installState = decoder.enum_tag();
// decoding manifestUrl
AppsObjectItem.manifestUrl = decoder.url();
// decoding removable
AppsObjectItem.removable = decoder.bool();
// decoding status
AppsObjectItem.status = decoder.enum_tag();
// decoding updateManifestUrl
if (decoder.bool()) {
AppsObjectItem.updateManifestUrl = decoder.url();
}
// decoding updateState
AppsObjectItem.updateState = decoder.enum_tag();
// decoding updateUrl
if (decoder.bool()) {
AppsObjectItem.updateUrl = decoder.url();
}
// decoding allowedAutoDownload
AppsObjectItem.allowedAutoDownload = decoder.bool();
// decoding preloaded
AppsObjectItem.preloaded = decoder.bool();
// decoding progress
AppsObjectItem.progress = decoder.i64();
// decoding origin
AppsObjectItem.origin = decoder.string();
return AppsObjectItem;
}
result = DecodeAppsObject(decoder);
this.dispatchEvent(2, result);
}
// Event #33: APP_UNINSTALLED
else if (variant == 33) {
let result = null;
// decoding <no_name>
result = decoder.url();
this.dispatchEvent(3, result);
}
// Event #34: APP_UPDATE_AVAILABLE
else if (variant == 34) {
let result = null;
// decoding <no_name>
function DecodeAppsObject(decoder) {
let AppsObjectItem = {};
// decoding name
AppsObjectItem.name = decoder.string();
// decoding installState
AppsObjectItem.installState = decoder.enum_tag();
// decoding manifestUrl
AppsObjectItem.manifestUrl = decoder.url();
// decoding removable
AppsObjectItem.removable = decoder.bool();
// decoding status
AppsObjectItem.status = decoder.enum_tag();
// decoding updateManifestUrl
if (decoder.bool()) {
AppsObjectItem.updateManifestUrl = decoder.url();
}
// decoding updateState
AppsObjectItem.updateState = decoder.enum_tag();
// decoding updateUrl
if (decoder.bool()) {
AppsObjectItem.updateUrl = decoder.url();
}
// decoding allowedAutoDownload
AppsObjectItem.allowedAutoDownload = decoder.bool();
// decoding preloaded
AppsObjectItem.preloaded = decoder.bool();
// decoding progress
AppsObjectItem.progress = decoder.i64();
// decoding origin
AppsObjectItem.origin = decoder.string();
return AppsObjectItem;
}
result = DecodeAppsObject(decoder);
this.dispatchEvent(4, result);
}
// Event #35: APP_UPDATED
else if (variant == 35) {
let result = null;
// decoding <no_name>
function DecodeAppsObject(decoder) {
let AppsObjectItem = {};
// decoding name
AppsObjectItem.name = decoder.string();
// decoding installState
AppsObjectItem.installState = decoder.enum_tag();
// decoding manifestUrl
AppsObjectItem.manifestUrl = decoder.url();
// decoding removable
AppsObjectItem.removable = decoder.bool();
// decoding status
AppsObjectItem.status = decoder.enum_tag();
// decoding updateManifestUrl
if (decoder.bool()) {
AppsObjectItem.updateManifestUrl = decoder.url();
}
// decoding updateState
AppsObjectItem.updateState = decoder.enum_tag();
// decoding updateUrl
if (decoder.bool()) {
AppsObjectItem.updateUrl = decoder.url();
}
// decoding allowedAutoDownload
AppsObjectItem.allowedAutoDownload = decoder.bool();
// decoding preloaded
AppsObjectItem.preloaded = decoder.bool();
// decoding progress
AppsObjectItem.progress = decoder.i64();
// decoding origin
AppsObjectItem.origin = decoder.string();
return AppsObjectItem;
}
result = DecodeAppsObject(decoder);
this.dispatchEvent(5, result);
}
// Event #36: APP_UPDATING
else if (variant == 36) {
let result = null;
// decoding <no_name>
function DecodeAppsObject(decoder) {
let AppsObjectItem = {};
// decoding name
AppsObjectItem.name = decoder.string();
// decoding installState
AppsObjectItem.installState = decoder.enum_tag();
// decoding manifestUrl
AppsObjectItem.manifestUrl = decoder.url();
// decoding removable
AppsObjectItem.removable = decoder.bool();
// decoding status
AppsObjectItem.status = decoder.enum_tag();
// decoding updateManifestUrl
if (decoder.bool()) {
AppsObjectItem.updateManifestUrl = decoder.url();
}
// decoding updateState
AppsObjectItem.updateState = decoder.enum_tag();
// decoding updateUrl
if (decoder.bool()) {
AppsObjectItem.updateUrl = decoder.url();
}
// decoding allowedAutoDownload
AppsObjectItem.allowedAutoDownload = decoder.bool();
// decoding preloaded
AppsObjectItem.preloaded = decoder.bool();
// decoding progress
AppsObjectItem.progress = decoder.i64();
// decoding origin
AppsObjectItem.origin = decoder.string();
return AppsObjectItem;
}
result = DecodeAppsObject(decoder);
this.dispatchEvent(6, result);
}
// Event #37: APPSTATUS_CHANGED
else if (variant == 37) {
let result = null;
// decoding <no_name>
function DecodeAppsObject(decoder) {
let AppsObjectItem = {};
// decoding name
AppsObjectItem.name = decoder.string();
// decoding installState
AppsObjectItem.installState = decoder.enum_tag();
// decoding manifestUrl
AppsObjectItem.manifestUrl = decoder.url();
// decoding removable
AppsObjectItem.removable = decoder.bool();
// decoding status
AppsObjectItem.status = decoder.enum_tag();
// decoding updateManifestUrl
if (decoder.bool()) {
AppsObjectItem.updateManifestUrl = decoder.url();
}
// decoding updateState
AppsObjectItem.updateState = decoder.enum_tag();
// decoding updateUrl
if (decoder.bool()) {
AppsObjectItem.updateUrl = decoder.url();
}
// decoding allowedAutoDownload
AppsObjectItem.allowedAutoDownload = decoder.bool();
// decoding preloaded
AppsObjectItem.preloaded = decoder.bool();
// decoding progress
AppsObjectItem.progress = decoder.i64();
// decoding origin
AppsObjectItem.origin = decoder.string();
return AppsObjectItem;
}
result = DecodeAppsObject(decoder);
this.dispatchEvent(7, result);
}
else {
 console.error(`Unable to process variant #${variant}`); }
}
}

AppsEngineSession.prototype.APP_DOWNLOAD_FAILED_EVENT = 0;
AppsEngineSession.prototype.APP_INSTALLED_EVENT = 1;
AppsEngineSession.prototype.APP_INSTALLING_EVENT = 2;
AppsEngineSession.prototype.APP_UNINSTALLED_EVENT = 3;
AppsEngineSession.prototype.APP_UPDATE_AVAILABLE_EVENT = 4;
AppsEngineSession.prototype.APP_UPDATED_EVENT = 5;
AppsEngineSession.prototype.APP_UPDATING_EVENT = 6;
AppsEngineSession.prototype.APPSTATUS_CHANGED_EVENT = 7;
const AppsEngineMessages = {
CancelDownloadRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(0);
result = result.url(data.updateUrl);
return result.value();
}
},
CancelDownloadResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 0) {
// Success
let result = null;
// decoding <no_name>
function DecodeAppsObject(decoder) {
let AppsObjectItem = {};
// decoding name
AppsObjectItem.name = decoder.string();
// decoding installState
AppsObjectItem.installState = decoder.enum_tag();
// decoding manifestUrl
AppsObjectItem.manifestUrl = decoder.url();
// decoding removable
AppsObjectItem.removable = decoder.bool();
// decoding status
AppsObjectItem.status = decoder.enum_tag();
// decoding updateManifestUrl
if (decoder.bool()) {
AppsObjectItem.updateManifestUrl = decoder.url();
}
// decoding updateState
AppsObjectItem.updateState = decoder.enum_tag();
// decoding updateUrl
if (decoder.bool()) {
AppsObjectItem.updateUrl = decoder.url();
}
// decoding allowedAutoDownload
AppsObjectItem.allowedAutoDownload = decoder.bool();
// decoding preloaded
AppsObjectItem.preloaded = decoder.bool();
// decoding progress
AppsObjectItem.progress = decoder.i64();
// decoding origin
AppsObjectItem.origin = decoder.string();
return AppsObjectItem;
}
result = DecodeAppsObject(decoder);
return { success: result }
}
else if (variant == 1) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`CancelDownloadResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
CheckForUpdateRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(1);
result = result.url(data.updateUrl);
result = result.bool(data.appsOption !== undefined);
if (data.appsOption !== undefined) {
// AppsOptions
function EncodeAppsOptions(AppsOptionsItem, result) {
result = result.bool(AppsOptionsItem.autoInstall !== undefined);
if (AppsOptionsItem.autoInstall !== undefined) {
result = result.bool(AppsOptionsItem.autoInstall);
}
return result;
}
result = EncodeAppsOptions(data.appsOption, result);
}
return result.value();
}
},
CheckForUpdateResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 2) {
// Success
let result = null;
// decoding <no_name>
result = decoder.bool();
return { success: result }
}
else if (variant == 3) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`CheckForUpdateResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
ClearRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(2);
result = result.url(data.manifestUrl);
result = result.enum_tag(data.dataType);
return result.value();
}
},
ClearResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 4) {
// Success
let result = null;
// decoding <no_name>
result = decoder.bool();
return { success: result }
}
else if (variant == 5) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`ClearResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetAllRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(3);
return result.value();
}
},
GetAllResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 6) {
// Success
let result = null;
// decoding <no_name>
if (decoder.bool()) {
let count = decoder.u64();
result = [];
for (let i = 0; i < count; i++) {
function DecodeAppsObject(decoder) {
let AppsObjectItem = {};
// decoding name
AppsObjectItem.name = decoder.string();
// decoding installState
AppsObjectItem.installState = decoder.enum_tag();
// decoding manifestUrl
AppsObjectItem.manifestUrl = decoder.url();
// decoding removable
AppsObjectItem.removable = decoder.bool();
// decoding status
AppsObjectItem.status = decoder.enum_tag();
// decoding updateManifestUrl
if (decoder.bool()) {
AppsObjectItem.updateManifestUrl = decoder.url();
}
// decoding updateState
AppsObjectItem.updateState = decoder.enum_tag();
// decoding updateUrl
if (decoder.bool()) {
AppsObjectItem.updateUrl = decoder.url();
}
// decoding allowedAutoDownload
AppsObjectItem.allowedAutoDownload = decoder.bool();
// decoding preloaded
AppsObjectItem.preloaded = decoder.bool();
// decoding progress
AppsObjectItem.progress = decoder.i64();
// decoding origin
AppsObjectItem.origin = decoder.string();
return AppsObjectItem;
}
result.push(DecodeAppsObject(decoder));
}
}
return { success: result }
}
else if (variant == 7) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`GetAllResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetAppRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(4);
result = result.url(data.manifestUrl);
return result.value();
}
},
GetAppResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 8) {
// Success
let result = null;
// decoding <no_name>
function DecodeAppsObject(decoder) {
let AppsObjectItem = {};
// decoding name
AppsObjectItem.name = decoder.string();
// decoding installState
AppsObjectItem.installState = decoder.enum_tag();
// decoding manifestUrl
AppsObjectItem.manifestUrl = decoder.url();
// decoding removable
AppsObjectItem.removable = decoder.bool();
// decoding status
AppsObjectItem.status = decoder.enum_tag();
// decoding updateManifestUrl
if (decoder.bool()) {
AppsObjectItem.updateManifestUrl = decoder.url();
}
// decoding updateState
AppsObjectItem.updateState = decoder.enum_tag();
// decoding updateUrl
if (decoder.bool()) {
AppsObjectItem.updateUrl = decoder.url();
}
// decoding allowedAutoDownload
AppsObjectItem.allowedAutoDownload = decoder.bool();
// decoding preloaded
AppsObjectItem.preloaded = decoder.bool();
// decoding progress
AppsObjectItem.progress = decoder.i64();
// decoding origin
AppsObjectItem.origin = decoder.string();
return AppsObjectItem;
}
result = DecodeAppsObject(decoder);
return { success: result }
}
else if (variant == 9) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`GetAppResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetStateRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(5);
return result.value();
}
},
GetStateResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 10) {
// Success
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { success: result }
}
else if (variant == 11) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetStateResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
GetUpdatePolicyRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(6);
return result.value();
}
},
GetUpdatePolicyResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 12) {
// Success
let result = null;
// decoding <no_name>
function DecodeUpdatePolicy(decoder) {
let UpdatePolicyItem = {};
// decoding enabled
UpdatePolicyItem.enabled = decoder.bool();
// decoding connType
UpdatePolicyItem.connType = decoder.enum_tag();
// decoding delay
UpdatePolicyItem.delay = decoder.i64();
return UpdatePolicyItem;
}
result = DecodeUpdatePolicy(decoder);
return { success: result }
}
else if (variant == 13) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`GetUpdatePolicyResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
InstallPackageRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(7);
result = result.url(data.updateUrl);
return result.value();
}
},
InstallPackageResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 14) {
// Success
let result = null;
// decoding <no_name>
function DecodeAppsObject(decoder) {
let AppsObjectItem = {};
// decoding name
AppsObjectItem.name = decoder.string();
// decoding installState
AppsObjectItem.installState = decoder.enum_tag();
// decoding manifestUrl
AppsObjectItem.manifestUrl = decoder.url();
// decoding removable
AppsObjectItem.removable = decoder.bool();
// decoding status
AppsObjectItem.status = decoder.enum_tag();
// decoding updateManifestUrl
if (decoder.bool()) {
AppsObjectItem.updateManifestUrl = decoder.url();
}
// decoding updateState
AppsObjectItem.updateState = decoder.enum_tag();
// decoding updateUrl
if (decoder.bool()) {
AppsObjectItem.updateUrl = decoder.url();
}
// decoding allowedAutoDownload
AppsObjectItem.allowedAutoDownload = decoder.bool();
// decoding preloaded
AppsObjectItem.preloaded = decoder.bool();
// decoding progress
AppsObjectItem.progress = decoder.i64();
// decoding origin
AppsObjectItem.origin = decoder.string();
return AppsObjectItem;
}
result = DecodeAppsObject(decoder);
return { success: result }
}
else if (variant == 15) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`InstallPackageResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
InstallPwaRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(8);
result = result.url(data.manifestUrl);
return result.value();
}
},
InstallPwaResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 16) {
// Success
let result = null;
// decoding <no_name>
function DecodeAppsObject(decoder) {
let AppsObjectItem = {};
// decoding name
AppsObjectItem.name = decoder.string();
// decoding installState
AppsObjectItem.installState = decoder.enum_tag();
// decoding manifestUrl
AppsObjectItem.manifestUrl = decoder.url();
// decoding removable
AppsObjectItem.removable = decoder.bool();
// decoding status
AppsObjectItem.status = decoder.enum_tag();
// decoding updateManifestUrl
if (decoder.bool()) {
AppsObjectItem.updateManifestUrl = decoder.url();
}
// decoding updateState
AppsObjectItem.updateState = decoder.enum_tag();
// decoding updateUrl
if (decoder.bool()) {
AppsObjectItem.updateUrl = decoder.url();
}
// decoding allowedAutoDownload
AppsObjectItem.allowedAutoDownload = decoder.bool();
// decoding preloaded
AppsObjectItem.preloaded = decoder.bool();
// decoding progress
AppsObjectItem.progress = decoder.i64();
// decoding origin
AppsObjectItem.origin = decoder.string();
return AppsObjectItem;
}
result = DecodeAppsObject(decoder);
return { success: result }
}
else if (variant == 17) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`InstallPwaResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SetEnabledRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(9);
result = result.url(data.manifestUrl);
result = result.enum_tag(data.status);
return result.value();
}
},
SetEnabledResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 18) {
// Success
let result = null;
// decoding <no_name>
function DecodeAppsObject(decoder) {
let AppsObjectItem = {};
// decoding name
AppsObjectItem.name = decoder.string();
// decoding installState
AppsObjectItem.installState = decoder.enum_tag();
// decoding manifestUrl
AppsObjectItem.manifestUrl = decoder.url();
// decoding removable
AppsObjectItem.removable = decoder.bool();
// decoding status
AppsObjectItem.status = decoder.enum_tag();
// decoding updateManifestUrl
if (decoder.bool()) {
AppsObjectItem.updateManifestUrl = decoder.url();
}
// decoding updateState
AppsObjectItem.updateState = decoder.enum_tag();
// decoding updateUrl
if (decoder.bool()) {
AppsObjectItem.updateUrl = decoder.url();
}
// decoding allowedAutoDownload
AppsObjectItem.allowedAutoDownload = decoder.bool();
// decoding preloaded
AppsObjectItem.preloaded = decoder.bool();
// decoding progress
AppsObjectItem.progress = decoder.i64();
// decoding origin
AppsObjectItem.origin = decoder.string();
return AppsObjectItem;
}
result = DecodeAppsObject(decoder);
return { success: result }
}
else if (variant == 19) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`SetEnabledResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SetTokenProviderRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(10);
result = result.u32(data.provider.id);
return result.value();
}
},
SetTokenProviderResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 20) {
// Success
let result = null;
// decoding <no_name>
result = decoder.void();
return { success: result }
}
else if (variant == 21) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`SetTokenProviderResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
SetUpdatePolicyRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(11);
// UpdatePolicy
function EncodeUpdatePolicy(UpdatePolicyItem, result) {
result = result.bool(UpdatePolicyItem.enabled);
result = result.enum_tag(UpdatePolicyItem.connType);
result = result.i64(UpdatePolicyItem.delay);
return result;
}
result = EncodeUpdatePolicy(data.config, result);
return result.value();
}
},
SetUpdatePolicyResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 22) {
// Success
let result = null;
// decoding <no_name>
result = decoder.bool();
return { success: result }
}
else if (variant == 23) {
// Error
let result = null;
// decoding <no_name>
result = decoder.void();
return { error: result }
}
else {
console.error(`SetUpdatePolicyResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
UninstallRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(12);
result = result.url(data.manifestUrl);
return result.value();
}
},
UninstallResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 24) {
// Success
let result = null;
// decoding <no_name>
result = decoder.url();
return { success: result }
}
else if (variant == 25) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`UninstallResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
UpdateRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(13);
result = result.url(data.manifestUrl);
result = result.bool(data.appsOption !== undefined);
if (data.appsOption !== undefined) {
// AppsOptions
function EncodeAppsOptions(AppsOptionsItem, result) {
result = result.bool(AppsOptionsItem.autoInstall !== undefined);
if (AppsOptionsItem.autoInstall !== undefined) {
result = result.bool(AppsOptionsItem.autoInstall);
}
return result;
}
result = EncodeAppsOptions(data.appsOption, result);
}
return result.value();
}
},
UpdateResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 26) {
// Success
let result = null;
// decoding <no_name>
function DecodeAppsObject(decoder) {
let AppsObjectItem = {};
// decoding name
AppsObjectItem.name = decoder.string();
// decoding installState
AppsObjectItem.installState = decoder.enum_tag();
// decoding manifestUrl
AppsObjectItem.manifestUrl = decoder.url();
// decoding removable
AppsObjectItem.removable = decoder.bool();
// decoding status
AppsObjectItem.status = decoder.enum_tag();
// decoding updateManifestUrl
if (decoder.bool()) {
AppsObjectItem.updateManifestUrl = decoder.url();
}
// decoding updateState
AppsObjectItem.updateState = decoder.enum_tag();
// decoding updateUrl
if (decoder.bool()) {
AppsObjectItem.updateUrl = decoder.url();
}
// decoding allowedAutoDownload
AppsObjectItem.allowedAutoDownload = decoder.bool();
// decoding preloaded
AppsObjectItem.preloaded = decoder.bool();
// decoding progress
AppsObjectItem.progress = decoder.i64();
// decoding origin
AppsObjectItem.origin = decoder.string();
return AppsObjectItem;
}
result = DecodeAppsObject(decoder);
return { success: result }
}
else if (variant == 27) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`UpdateResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
VerifyRequest: {
encode: (data) => {
let encoder = new Encoder();
let result = encoder.enum_tag(14);
result = result.url(data.manifestUrl);
result = result.string(data.certType);
result = result.string(data.folderName);
return result.value();
}
},
VerifyResponse: {
decode: (buffer , service_id, session) => {
let decoder = new Decoder(buffer);
let variant = decoder.enum_tag();
if (variant == 28) {
// Success
let result = null;
// decoding <no_name>
result = decoder.string();
return { success: result }
}
else if (variant == 29) {
// Error
let result = null;
// decoding <no_name>
result = decoder.enum_tag();
return { error: result }
}
else {
console.error(`VerifyResponse::decode: Unexpected variant ${variant}`);
return null;
}
}
},
}

export class TokenProviderBase extends SessionObject {
constructor(service_id, session) {
super(session.next_id , session, service_id, null);
session.track(this);
}
static fromFunction(service_id, session, fn) {
let obj = new TokenProviderBase(service_id, session);
obj.getToken = fn.bind(obj);
return obj;
}
on_message(message) {
            // console.log(`Message for TokenProvider ${this.display()}: %o`, message);
let decoder = new Decoder(message.content);
        let variant = decoder.enum_tag();
        // console.log(`Starting at index 38`);
        // console.log(`we got variant ${variant}`);
        // Dispatch based on message.content which is the real payload.
        
switch (variant) {
case 38: {
// console.log(`Extracting parameters for getToken(...)`);
if (this.getToken && this.getToken instanceof Function) {
let result = {};
// decoding tokenType
result.tokenType = decoder.enum_tag();
let output = this.getToken(
result.tokenType
);
output.then(
success => { // console.log(`TokenProvider.getToken success: ${success}`);
let encoder = new Encoder();
let result = encoder.enum_tag(15);
// Token
function EncodeToken(TokenItem, result) {
result = result.string(TokenItem.keyId);
result = result.string(TokenItem.macKey);
result = result.enum_tag(TokenItem.tokenType);
return result;
}
result = EncodeToken(success, result);
message.content = result.value();
this.send_callback_message(message);
},
error => { // console.error(`TokenProvider.getToken error: ${error}`);
let encoder = new Encoder();
let result = encoder.enum_tag(16);
result = result.void(error);
message.content = result.value();
this.send_callback_message(message);
}
);
}
break; }
default: console.error(`Unexpected variant: ${variant}`);
}
}
}

export const AppsManager = {
            get: (session) => {
                return Services.get("AppsManager", "3194da7e436415aa4eb76f9992724b57298526e2dbb31721b6342e39f299ec", session).then((service_id) => {
                    session.registerService(service_id, "AppsManager");
                    // object_id is always 0 for the service itself.
                    return new AppsEngineSession(0, service_id, session);
                });
            },
        };
function wrapBlob(blob) {
            let btype = blob.type;
            return blob.arrayBuffer().then(data => {
                return { __isblob__: true, data: new Uint8Array(data), type: btype }
            });
        }